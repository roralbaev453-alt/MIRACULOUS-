export type Language = "uz" | "ru" | "en";

export interface TranslationDict {
  logoTitle: string;
  login: string;
  logout: string;
  registeredAs: string;
  home: string;
  socials: string;
  payment: string;
  unlockTitle: string;
  unlockDesc: string;
  categoriesHeader: string;
  categoriesSubtitle: string;
  templatesCount: string;
  openButton: string;
  heroTitle1: string;
  heroTitle2: string;
  heroDesc: string;
  heroBtn: string;
  statsTitle: string;
  statsDesc: string;
  previewMode: string;
  slidesCount: string;
  addSlide: string;
  copySlide: string;
  copyAll: string;
  presentationMode: string;
  exitTheatre: string;
  slideTitle: string;
  slideSubtitle: string;
  slideContent: string;
  slideLayout: string;
  accentColors: string;
  orqaFonlar: string;
  guestWarning: string;
  guestDescription: string;
  unlockActionBtn: string;
  purchasedCongrats: string;
  purchasedDesc: string;
  loginRequiredTitle: string;
  loginRequiredDesc: string;
  loginBtnLabel: string;
  cardNumLabel: string;
  cardHolderLabel: string;
  secureContract: string;
  secureDesc: string;
  confirmUnlock: string;
  processing: string;
  slideIndicator: string;
  travel: string;
  history: string;
  architecture: string;
  business: string;
  medicine: string;
  sciences: string;
  sport: string;
  nature: string;
  construction: string;
  noPremiumSubscription: string;
  copiedSuccess: string;
  copiedAllSuccess: string;
  oneTimeUnlock: string;
}

export const TRANSLATIONS: Record<Language, TranslationDict> = {
  uz: {
    logoTitle: "Miraculous Slides",
    login: "Kirish",
    logout: "Chiqish",
    registeredAs: "Foydalanuvchi",
    home: "Bosh sahifa",
    socials: "Ijtimoiy Tarmoq",
    payment: "To'lov",
    unlockTitle: "SHABLONNI FAOLLASHTIRISH",
    unlockDesc: "Ushbu tayyor andozali animatsion slaydlarni yuklab olish va andozangizni faollashtirish.",
    categoriesHeader: "BIZ SIZGA SHULARNI",
    categoriesSubtitle: "TAQDIM QILAMIZ",
    templatesCount: "andozalar",
    openButton: "Ochish",
    heroTitle1: "ANIMATSION SHABLONLAR",
    heroTitle2: "GALEREYASI",
    heroDesc: "Professional darajada yaratilgan va tayyor animatsiyaga ega darslik hamda prezentatsiya shablonlari. Gmail orqali tezda kiring, andozalarni tanlang va o'zingizga yuklab oling!",
    heroBtn: "Shablonlarni ko'rish",
    statsTitle: "BIZNING KO'RSATKICHLAR",
    statsDesc: "Slaydlarimizning xalqaro darajadagi ko'rsatkichlari",
    previewMode: "Slayd Rejimi",
    slidesCount: "SLAYDLAR",
    addSlide: "Qo'shish",
    copySlide: "Nusxalash",
    copyAll: "Barchasini Ko'chirish",
    presentationMode: "Prezentatsiya (F5)",
    exitTheatre: "Chiqish",
    slideTitle: "Slayd Sarlavhasi",
    slideSubtitle: "Kichik sarlavha (Kicker)",
    slideContent: "Asosiy ma'lumot matni",
    slideLayout: "Slayd Tuzilishi",
    accentColors: "Neon Ranglar",
    orqaFonlar: "Orqa fonlar",
    guestWarning: "Shablonlarni ko'rish uchun kirish zarur",
    guestDescription: "Siz hozirda andozalarni to'liq ko'ra olmaysiz. Iltimos, darslik shablonlarini ko'rish uchun avval Gmail orqali ro'yxatdan o'ting. Ro'yxatdan o'tgach shablon faol ochiladi va to'liq to'lov orqali yuklab olishingiz mumkin.",
    unlockActionBtn: "Slaydni Yuklab olish",
    purchasedCongrats: "Shablon muvaffaqiyatli sotib olindi!",
    purchasedDesc: "Siz ushbu tayyor animatsion andozani to'liq qo'lga kiritdingiz. Endi uni bemalol tahrirlashingiz, nusxalamoqchi bo'lgan ma'lumotlarni ko'chirishingiz mumkin!",
    loginRequiredTitle: "Gmail orqali kirish",
    loginRequiredDesc: "Siz andozalarni ko'rish va ishlashdan oldin tizimga ro'yxatdan o'tishingiz (Gmail orqali kirshingiz) shart. Bu mutlaqo bepul!",
    loginBtnLabel: "Tizimga kirish (Gmail)",
    cardNumLabel: "Karta raqami (8600 / 9860 / 4444 ...)",
    cardHolderLabel: "Karta egasining ismi",
    secureContract: "To'g'ridan-to'g'ri Kafolatlangan To'lov",
    secureDesc: "Ushbu to'lov CLICK, PAYME va VISA xavfsizlik protokollari doirasida asralgan va xavfsiz amalga oshiriladi.",
    confirmUnlock: "To'lovni tasdiqlash",
    processing: "To'lov jarayoni...",
    slideIndicator: "Slayd",
    travel: "Sayohat",
    history: "Tarix",
    architecture: "Me'morchilik",
    business: "Biznes",
    medicine: "Tibbiyot",
    sciences: "Fan olami",
    sport: "Sport",
    nature: "Tabiat",
    construction: "Qurilish",
    noPremiumSubscription: "Menda Premium Obuna yo'q, faqat bir marta faollashtirish",
    copiedSuccess: "Nusxalandi!",
    copiedAllSuccess: "Hammasi ko'chirildi!",
    oneTimeUnlock: "Ushbu andozani to'liq faollashtirish (CLICK/PAYME/VISA)"
  },
  ru: {
    logoTitle: "Miraculous Slides",
    login: "Войти",
    logout: "Выйти",
    registeredAs: "Пользователь",
    home: "Главная",
    socials: "Соцсети",
    payment: "Оплата",
    unlockTitle: "АКТИВАЦИЯ ШАБЛОНА",
    unlockDesc: "Скачайте эти готовые анимированные шаблоны слайдов и активируйте свой доступ к шаблону.",
    categoriesHeader: "МЫ ПРЕДСТАВЛЯЕМ",
    categoriesSubtitle: "ВАШЕМУ ВНИМАНИЮ",
    templatesCount: "шаблонов",
    openButton: "Открыть",
    heroTitle1: "ГАЛЕРЕЯ АНИМИРОВАННЫХ",
    heroTitle2: "ШАБЛОНОВ",
    heroDesc: "Профессионально разработанные шаблоны презентаций с готовой анимацией. Быстро авторизуйтесь через Gmail, выберите нужный шаблон и скачайте его прямо сейчас!",
    heroBtn: "Смотреть шаблоны",
    statsTitle: "НАШИ ПОКАЗАТЕЛИ",
    statsDesc: "Международные показатели успеха наших презентаций",
    previewMode: "Режим слайда",
    slidesCount: "СЛАЙДЫ",
    addSlide: "Добавить",
    copySlide: "Копировать",
    copyAll: "Копировать Всё",
    presentationMode: "Презентация (F5)",
    exitTheatre: "Выйти",
    slideTitle: "Заголовок слайда",
    slideSubtitle: "Подзаголовок (Кикер)",
    slideContent: "Текст основного содержания",
    slideLayout: "Структура слайда",
    accentColors: "Неоновые цвета",
    orqaFonlar: "Фоновые стили",
    guestWarning: "Для просмотра шаблонов необходима авторизация",
    guestDescription: "В настоящее время вы не можете полноценно просматривать шаблоны. Пожалуйста, сначала войдите через Gmail, чтобы увидеть наши анимированные слайды. После входа шаблоны станут доступны, и вы сможете разблокировать их полной оплатой.",
    unlockActionBtn: "Скачать этот шаблон",
    purchasedCongrats: "Шаблон успешно активирован!",
    purchasedDesc: "Вы полностью разблокировали этот готовый анимированный шаблон. Теперь вы можете свободно редактировать его и копировать нужные данные!",
    loginRequiredTitle: "Вход через Gmail",
    loginRequiredDesc: "Вам необходимо войти в систему (авторизоваться через Gmail), прежде чем просматривать шаблоны и работать с ними. Это абсолютно бесплатно!",
    loginBtnLabel: "Войти в систему (Gmail)",
    cardNumLabel: "Номер карты (8600 / 9860 / 4444 ...)",
    cardHolderLabel: "Имя владельца карты",
    secureContract: "Прямая гарантированная оплата",
    secureDesc: "Этот платеж защищен в рамках протоколов безопасности CLICK, PAYME и VISA и осуществляется безопасно.",
    confirmUnlock: "Подтвердить оплату",
    processing: "Обработка платежа...",
    slideIndicator: "Слайд",
    travel: "Путешествия",
    history: "История",
    architecture: "Архитектура",
    business: "Бизнес",
    medicine: "Медицина",
    sciences: "Наука",
    sport: "Спорт",
    nature: "Природа",
    construction: "Строительство",
    noPremiumSubscription: "У меня нет премиум-подписки, только разовая покупка",
    copiedSuccess: "Скопировано!",
    copiedAllSuccess: "Всё скопировано!",
    oneTimeUnlock: "Полная активация этого шаблона (CLICK/PAYME/VISA)"
  },
  en: {
    logoTitle: "Miraculous Slides",
    login: "Log in",
    logout: "Log out",
    registeredAs: "User",
    home: "Home",
    socials: "Social Feed",
    payment: "Payment",
    unlockTitle: "ACTIVATE TEMPLATE",
    unlockDesc: "Download these fully prepared animated slides and permanently activate this template deck.",
    categoriesHeader: "OUR EXQUISITE",
    categoriesSubtitle: "COLLECTION FOR YOU",
    templatesCount: "templates",
    openButton: "Open",
    heroTitle1: "ANIMATED TEMPLATE",
    heroTitle2: "GALLERY",
    heroDesc: "Professionally curated, beautifully pre-animated educational and presentation templates. Log in quickly with Gmail, select your favorite templates, and download them now!",
    heroBtn: "Browse Templates",
    statsTitle: "OUR STATISTICS",
    statsDesc: "Global performance markers of our prepared animated slides",
    previewMode: "Slide Layout",
    slidesCount: "SLIDES",
    addSlide: "Add Slide",
    copySlide: "Copy Text",
    copyAll: "Copy All Slides",
    presentationMode: "Presentation (F5)",
    exitTheatre: "Exit Screen",
    slideTitle: "Slide Title",
    slideSubtitle: "Section Subtitle (Kicker)",
    slideContent: "Main Content Paragraphs",
    slideLayout: "Slide Structural Grid",
    accentColors: "Neon Color Schemes",
    orqaFonlar: "Backgrounds",
    guestWarning: "Authentication required to view templates",
    guestDescription: "You are currently a guest. Please sign in via Gmail first to unlock full browsing of our pre-animated slide decks. Once registered, templates open up, and you can fully unlock/download them with a one-time purchase.",
    unlockActionBtn: "Download This Template",
    purchasedCongrats: "Template successfully activated!",
    purchasedDesc: "You have fully unlocked this prepared animated template asset! You are free to edit, customize, and copy the slide text elements.",
    loginRequiredTitle: "Sign in with Gmail",
    loginRequiredDesc: "You must first sign in with Gmail/email to look at and view our presentation templates. It is 100% free!",
    loginBtnLabel: "Register with Gmail (Free)",
    cardNumLabel: "Card number (8600 / 9860 / 4444...)",
    cardHolderLabel: "Cardholder Name",
    secureContract: "Direct Guaranteed Payment Gateway",
    secureDesc: "This payment is secured via top standard CLICK, PAYME, and VISA secure layers. Encrypted transfer guaranteed.",
    confirmUnlock: "Confirm Unlock Payment",
    processing: "Processing Payment...",
    slideIndicator: "Slide",
    travel: "Travels",
    history: "History",
    architecture: "Architecture",
    business: "Business",
    medicine: "Medicine",
    sciences: "Sciences",
    sport: "Sport",
    nature: "Nature",
    construction: "Construction",
    noPremiumSubscription: "I don't have premium subscriptions, only one-time unlock payments",
    copiedSuccess: "Copied!",
    copiedAllSuccess: "All copied!",
    oneTimeUnlock: "Unlock full template & download (CLICK/PAYME/VISA)"
  }
};
