import React, { useState } from "react";
import { User, CategoryId } from "./types";
import { Language } from "./translations";

// Import custom modular components
import Header from "./components/Header";
import Hero from "./components/Hero";
import Stats from "./components/Stats";
import SliderSection from "./components/SliderSection";
import CategoryGrid from "./components/CategoryGrid";
import SocialBuilder from "./components/SocialBuilder";
import SlideEditor from "./components/SlideEditor";
import LoginModal from "./components/LoginModal";
import PaymentModal from "./components/PaymentModal";

export default function App() {
  const [activeTab, setActiveTab] = useState<string>("landing");
  const [user, setUser] = useState<User | null>(null);
  const [lang, setLang] = useState<Language>("uz");

  // Keep track of which slide categories have been purchased and unlocked
  const [unlockedCategories, setUnlockedCategories] = useState<CategoryId[]>([]);

  // Modal display states
  const [isLoginOpen, setIsLoginOpen] = useState(false);
  const [isPaymentOpen, setIsPaymentOpen] = useState(false);

  // Selected category for the slides editor workspace
  const [selectedCategory, setSelectedCategory] = useState<CategoryId>("sayohat");

  // Handle category selected from cards or tiles
  const handleSelectCategory = (catId: string) => {
    setSelectedCategory(catId as CategoryId);
    setActiveTab("editor");
    
    // Smooth scroll user to top of workspace
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  const handleLoginSuccess = (email: string, name: string) => {
    setUser({
      email,
      name,
      isPremium: true,
      tier: 1,
    });
    setIsLoginOpen(false);
  };

  const handlePaymentSuccess = () => {
    // Permanently unlock the current selected category upon payment checkout
    setUnlockedCategories((prev) => {
      if (!prev.includes(selectedCategory)) {
        return [...prev, selectedCategory];
      }
      return prev;
    });
  };

  return (
    <div className="min-h-screen bg-[#09090b] text-zinc-100 flex flex-col font-sans selection:bg-teal-500/30 selection:text-teal-200">
      
      {/* Decorative Top Beam */}
      <div className="h-1 w-full bg-gradient-to-r from-teal-500 to-indigo-600 relative z-50" />

      {/* Shared Header bar */}
      <Header
        user={user}
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        onOpenLogin={() => setIsLoginOpen(true)}
        onOpenPayment={() => setIsPaymentOpen(true)}
        onLogout={() => setUser(null)}
        lang={lang}
        setLang={setLang}
      />

      {/* Main Pages and Sections */}
      <main className="grow">
        {activeTab === "landing" ? (
          <div>
            {/* Majestic Headline & 3D Staircase illustration */}
            <Hero onCreateClick={() => handleSelectCategory("sayohat")} lang={lang} />

            {/* Custom sliding glass cards deck */}
            <SliderSection onSelectCategory={handleSelectCategory} lang={lang} />

            {/* Bento dashboard metrics list */}
            <Stats lang={lang} />

            {/* Catalog list grid */}
            <CategoryGrid
              onSelectCategory={handleSelectCategory}
              selectedCategory={selectedCategory}
              lang={lang}
            />
          </div>
        ) : activeTab === "editor" ? (
          <SlideEditor
            category={selectedCategory}
            user={user}
            onUpgradePrompt={() => setIsPaymentOpen(true)}
            onOpenLogin={() => setIsLoginOpen(true)}
            lang={lang}
            hasUnlocked={unlockedCategories.includes(selectedCategory)}
          />
        ) : activeTab === "social" ? (
          <SocialBuilder />
        ) : null}
      </main>

      {/* Footer Branding block */}
      <footer className="border-t border-zinc-900 bg-zinc-950 py-8 px-4 text-center">
        <div className="mx-auto max-w-7xl flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="flex items-center space-x-2 font-mono">
            <span className="text-xl font-black text-white italic">M</span>
            <span className="text-xs font-mono text-zinc-600 block uppercase tracking-widest">
              MIRACULOUS PRE-ANIMATED TEMPLATE PLATFORM &copy; 2026
            </span>
          </div>
          <div className="text-[11px] font-mono text-zinc-500">
            Powered by AI &bull; O'zbekistonda barpo etilgan yangi avlod animatsion slayd darsligi ({lang.toUpperCase()})
          </div>
        </div>
      </footer>

      {/* Authentication Modal Popup */}
      <LoginModal
        isOpen={isLoginOpen}
        onClose={() => setIsLoginOpen(false)}
        onLoginSuccess={handleLoginSuccess}
        lang={lang}
      />

      {/* Subscription Pay Gate Popup */}
      <PaymentModal
        isOpen={isPaymentOpen}
        onClose={() => setIsPaymentOpen(false)}
        onPaymentSuccess={handlePaymentSuccess}
        lang={lang}
      />

    </div>
  );
}
