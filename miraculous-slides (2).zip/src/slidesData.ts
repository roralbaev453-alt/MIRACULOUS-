import { Slide, CategoryId } from "./types";
import { Language } from "./translations";

// Supplementary slides for all 9 categories up to 25 slides each in 3 languages
export const SUPPLEMENTARY_DATA: Record<CategoryId, Record<Language, { title: string; subtitle: string; content: string }[]>> = {
  sayohat: {
    uz: [
      { title: "Sayohat San'ati", subtitle: "Toshkent - Yangi Chegaralar", content: "Sayohat qilish - bu nafaqat masofalarni bosib o'tish, balki ruhiy rivojlanish va yangi do'stlar orttirishdir." },
      { title: "Yovvoyi Savanna", subtitle: "Keniyada unutilmas kunlar", content: "Afrika tabiati va uning to'lib-toshgan energiyasi har bir sayohatchining orzusidagi dunyodir." },
      { title: "Yevropa Nafasi", subtitle: "Tarix ko'chalari", content: "Gotika uslubidagi ibodatxonalar va shinam qahvaxonalar sizni sehrli dunyoga chorlaydi." },
      { title: "Osiyo Mo'jizalari", subtitle: "Sharq an'analari", content: "Kunchiqar yurt madaniyati, qadimiy ibodatxonalar va osmon o'par yuqori texnologiyali megapolislar uyg'unligi." },
      { title: "Okeaniya Sirlari", subtitle: "Tinch okeani durdonalari", content: "Tinch okeanining moviy suvlari va tropik jannatmonand orollarida sarguzashtlar." },
      { title: "Amerika Kanyonlari", subtitle: "Tabiat me'morchiligi", content: "Buyuk Kanyonning qizil qumtosh qoyalari va tabiy yaralgan ulug'vor daryo chuqurliklari." },
      { title: "Shimoliy Yog'du", subtitle: "Qutb kechasi", content: "Skandinaviya o'lkalari osmonida yashil va binafsha rangli chiroqlarning mo''jizaviy raqsi." },
      { title: "Sahroi Kabir barxanlari", subtitle: "Cheksiz qumliklar", content: "Oltin qum tepaliklari bo'ylab sokin harakatlanayotgan karvonlar va quyosh botish manzarasi." },
      { title: "Himolay Cho'qqilari", subtitle: "Dunyo tomi", content: "Tog' cho'qqilarini zabt etish orqali kishi o'z xarakterini tobora chiniqtiradi." },
      { title: "Qadimgi Rim sadosi", subtitle: "Imperiya izlari", content: "Kolizey gumbazlari ostida o'tmish qahramonlarining shonli tarixi va me'morchiligi." },
      { title: "Amazonka O'rmonlari", subtitle: "Yovvoyi tabiat bag'ri", content: "Dunyoning eng sersuv daryosi atrofidagi tropik o'rmonlar, noyob hayvonot dunyosi." },
      { title: "Gastronomik Sayohat", subtitle: "Lazzatlar dunyosi", content: "Turli milliy oshxonalar, o'ziga xos ziravorlar va taom tayyorlashning qadimiy sirlari." },
      { title: "Maldiv Havzasi", subtitle: "Moviy orollar", content: "Atoll ustidagi shinam villalar va sho'ng'uvchilar uchun ideal rang-barang marjon qoyalari." },
      { title: "Skandinaviya Fyordlari", subtitle: "Muzliklar vodiysi", content: "Norvegiyadagi salobatli tik qoyalar va ko'm-ko'k suv ostida suzayotgan kemalar go'zalligi." },
      { title: "Milliy Festivallar", subtitle: "Ranglar jilosi", content: "Braziliya karnavalidan tortib Yaponiyaning sakura gullash bayramigacha bo'lgan an'analar." },
      { title: "Yer osti mo'jizalari", subtitle: "Sirli g'orlar", content: "Tabiat tomonidan million yillar davomida tomchilab yaratilgan ulkan stalaktit ustunlari." },
      { title: "Ziyoratgohlar yo'li", subtitle: "Ruhiy osoyishtalik", content: "Muqaddas qadamjolarga sayohat qilish inson qalbiga sokinlik bag'ishlaydi." },
      { title: "Tarixiy saroylar", subtitle: "Qirollar davri", content: "Versal va London minoralaridagi boy bezaklar va tarixiy hujjatlar galereyasi." },
      { title: "Ekologik turizm", subtitle: "Tabiatni asrash", content: "Atrof-muhitga zarar yetkazmasdan sayohat qilish va yashil hayot madaniyatini targ'ib etish." },
      { title: "Viktoriya sharsharasi", subtitle: "Guldurayotgan tuman", content: "Zambezi daryosidan tushayotgan ulkan suv tonnalarining havoda yaratgan ajoyib kamalagi." },
      { title: "Trans-Sibir yo'li", subtitle: "Temir yo'l sarguzashtlari", content: "Uzoq o'lkalar bo'ylab vagon darchasidan tabiatning o'zgarishini kuzatish baxti." },
      { title: "Alyaska Muzliklari", subtitle: "Oq go'zallik", content: "Uzoq shimolning muz devorlari va uning bag'ridagi ulug'vor kitlar dunyosi." },
      { title: "Katta Marjon Rifi", subtitle: "Okean osti hayoti", content: "Dunyoning eng katta rifidagi ming xil rangdagi baliqlar va suvo'tlar." },
      { title: "Ipak yo'li karvonlar", subtitle: "Sharq ertaklari", content: "Qadimiy karvonsaroylar devorlari orasida saqlanib qolgan buyuk ipak yo'li nafasi." },
      { title: "Xulosa va Taassurot", subtitle: "Yangilanish onlari", content: "Har bir yangi sayohat inson dunyoqarashini o'zgartiradi va yangi marralar sari chorlaydi." }
    ],
    ru: [
      { title: "Искусство Путешествий", subtitle: "Новые Горизонты", content: "Путешествие – это не просто смена мест, а способ духовного развития и обретения друзей." },
      { title: "Дикая Саванна", subtitle: "Дни в Кении", content: "Природа Африки и ее мощная энергия – это мечта каждого настоящего путешественника." },
      { title: "Дыхание Европы", subtitle: "Улицы Истории", content: "Готические соборы и уютные кофейни зовут вас в мир вечной романтики и красоты." },
      { title: "Чудеса Азии", subtitle: "Традиции Востока", content: "Гармония древних храмов, рисовых полей и футуристических мегаполисов Азии." },
      { title: "Тайны Океании", subtitle: "Жемчужины Тихого океана", content: "Приключения на лазурных водах и тропических островах южных морей." },
      { title: "Американские Каньоны", subtitle: "Архитектура природы", content: "Величественные красные скалы Гранд-Каньона и глубокие долины рек." },
      { title: "Северное Сияние", subtitle: "Полярная сказка", content: "Волшебный танец изумрудных огней в ночном небе над заснеженной Скандинавией." },
      { title: "Барханы Сахары", subtitle: "Бескрайние пески", content: "Спокойное движение караванов среди золотых дюн под заходящим солнцем." },
      { title: "Вершины Гималаев", subtitle: "Крыша мира", content: "Покорение горных высот закаляет характер и открывает потрясающий вид." },
      { title: "Эхо Древнего Рима", subtitle: "Следы Империи", content: "Славная история гладиаторов и вечная монументальная архитектура под куполом Колизея." },
      { title: "Леса Амазонки", subtitle: "Сердце дикой природы", content: "Тропические джунгли у берегов величайшей реки мира с уникальной фауной." },
      { title: "Гастрономический Туризм", subtitle: "Мир вкусов", content: "Знакомство с секретами национальных кухонь и специями разных стран." },
      { title: "Мальдивский Бассейн", subtitle: "Лазурные виллы", content: "Уютные домики на воде и коралловые рифы для любителей дайвинга." },
      { title: "Скандинавские Фьорды", subtitle: "Долина ледников", content: "Величественные скалы Норвегии и прозрачные синие воды узких заливов." },
      { title: "Национальные Фестивали", subtitle: "Яркость культур", content: "От бразильского карнавала до праздника цветения сакуры в Японии." },
      { title: "Подземные Чудеса", subtitle: "Таинственные пещеры", content: "Сталактитовые залы, созданные природой на протяжении миллионов лет." },
      { title: "Путь Паломника", subtitle: "Духовный покой", content: "Посещение священных мест дарует умиротворение и внутреннюю силу." },
      { title: "Исторические Дворцы", subtitle: "Эпоха королей", content: "Роскошь убранства и архивные тайны Версаля и лондонского Тауэра." },
      { title: "Экологический Туризм", subtitle: "Берегите планету", content: "Путешествия без вреда для экологии и поддержка концепции зеленой жизни." },
      { title: "Водопад Виктория", subtitle: "Гремящий дым", content: "Огромные потоки воды реки Замбези, образующие вечную радугу в брызгах." },
      { title: "Транссибирский Экспресс", subtitle: "Дорога через страны", content: "Уникальное приключение в поезде с видом на меняющиеся природные пейзажи." },
      { title: "Ледники Аляски", subtitle: "Белое величие", content: "Ледяные исполины крайнего севера и захватывающие встречи с китами." },
      { title: "Большой Барьерный Риф", subtitle: "Жизнь под водой", content: "Красочный мир рыб и морских кораллов в крупнейшей рифовой системе." },
      { title: "Караваны Шелкового Пути", subtitle: "Сказки Востока", content: "Дух древней торговли, сохранившийся в стенах старинных караван-сараев." },
      { title: "Заключение и Итоги", subtitle: "Время меняться", content: "Каждое путешествие меняет наш внутренний мир и вдохновляет на большее." }
    ],
    en: [
      { title: "Art of Travel", subtitle: "New Horizons", content: "Traveling is not just moving in space, but a way to expand your soul and meet friends." },
      { title: "Wild Savanna", subtitle: "Days in Kenya", content: "The raw nature of Africa and its vibrant wildlife is the ultimate dream of every traveler." },
      { title: "Breath of Europe", subtitle: "Streets of History", content: "Gothic cathedrals and cozy cafes call you into a world of eternal romance." },
      { title: "Wonders of Asia", subtitle: "Eastern Traditions", content: "The perfect harmony of ancient temples, rice fields, and high-tech megapolises." },
      { title: "Secrets of Oceania", subtitle: "Pacific Gems", content: "Adventures on the turquoise waters and tropical islands of south seas." },
      { title: "American Canyons", subtitle: "Nature's Architecture", content: "The majestic red rocks of Grand Canyon and historic river paths." },
      { title: "Northern Lights", subtitle: "Polar Magic", content: "A magical dance of emerald and purple lights in the polar night sky." },
      { title: "Sands of Sahara", subtitle: "Endless Dunes", content: "A silent caravan moving across golden dunes under the setting sun." },
      { title: "Peaks of Himalayas", subtitle: "Roof of the World", content: "Conquering mountain heights trains your character and offers breathtaking views." },
      { title: "Ancient Rome Echo", subtitle: "Traces of Empire", content: "Glorious history of gladiators and eternal monumental arch design under the Colosseum dome." },
      { title: "Amazon Rainforest", subtitle: "Heart of the Wild", content: "Tropical jungles near the world's most powerful river with highly unique fauna." },
      { title: "Gastronomic Tourism", subtitle: "World of Flavors", content: "Exploring the secrets of national cuisines and spices across different countries." },
      { title: "Maldives Basin", subtitle: "Azure Villas", content: "Charming overwater bungalows and amazing coral reefs for diving lovers." },
      { title: "Scandinavian Fjords", subtitle: "Glacier Valley", content: "Majestic steep cliffs of Norway and crystal clear blue sea waters." },
      { title: "National Festivals", subtitle: "Vibrant Cultures", content: "From Brazilian carnivals to Cherry Blossom festivals in Tokyo." },
      { title: "Subterranean Wonders", subtitle: "Mysterious Caves", content: "Stalactite columns drops-sculptured by nature over millions of years." },
      { title: "Pilgrim's Path", subtitle: "Spiritual Tranquility", content: "Visiting holy sites brings peacefulness and inner power to the traveler." },
      { title: "Historic Palaces", subtitle: "Royal Epoch", content: "The luxury of decors and archive files at Versailles and Tower of London." },
      { title: "Eco-tourism", subtitle: "Save the Planet", content: "Traveling without footprint and learning the green way of sustainable living." },
      { title: "Victoria Falls", subtitle: "Thunderous Smoke", content: "Enormous water columns of Zambezi river creating marvelous rainbows in the mist." },
      { title: "Trans-Siberian Railroad", subtitle: "Train Adventures", content: "Long journey crossing several time zones with changing natural backdrops." },
      { title: "Alaska Glaciers", subtitle: "White Majesty", content: "Ice giants of the far north and breath-taking close whale interactions." },
      { title: "Great Barrier Reef", subtitle: "Undersea Wildlife", content: "Colorful fish and coral species in the largest reef system on Earth." },
      { title: "Silk Road Caravans", subtitle: "Oriental Tales", content: "Distant trade echoes preserved inside walls of ancient clay caravanserais." },
      { title: "Conclusion & Takeaways", subtitle: "Ready to Evolve", content: "Every trip changes our inner beliefs and inspires us to achieve higher goals." }
    ]
  },
  tarix: {
    uz: [
      { title: "Misr Ehromlari", subtitle: "Giza sirlari va Fir'avn xazinalari", content: "Ulkan toshlardan qurilgan ehromlar ming yillar davomida dunyo me'morlarini hayratda qoldirib kelmoqda." },
      { title: "Buyuk Ipak Yo'li", subtitle: "Madaniyatlar ko'prigi", content: "Samarqand va Buxoro chorrahasida Sharq sirlari va G'arb fanining uyg'unlashuvi boshlangan." },
      { title: "Qadimgi Yunoniston", subtitle: "Demokratiya beshigi", content: "Afina davlat tizimi, falsafa va antik davlat arxitekturasi butun jahon sivilizatsiyasiga tamal toshi bo'ldi." },
      { title: "Rim Imperiyasi", subtitle: "Tinchlik va Qonun", content: "Buyuk yo'llar, huquqiy normalar va yengilmas legionlar tarixda o'chmas iz qoldirdi." },
      { title: "O'rta Asr Ritsarlari", subtitle: "Sharaf va Jasorat", content: "Temir sovutlar kiygan jangchilar, muhtasham tosh qal'alar va xonimlar sharafiga uyushtirilgan turnirlar." },
      { title: "Temuriylar Renessansi", subtitle: "Sharq Uyg'onishi", content: "Ilm-fan, astronomiya, tibbiyot va nafis me'morchilikning saltanat bo'ylab jadal yuksalishi." },
      { title: "Uyg'onish Davri", subtitle: "San'at va Insoniylik", content: "Leonardo da Vinchi va Mikelanjelo asarlari inson aql-zakovatining mislsiz cheksizligini namoyish etdi." },
      { title: "Sanoat Inqilobi", subtitle: "Mashinalar erasi", content: "Bug' dvigateli va birinchi zavodlarning paydo bo'lishi insoniyat taraqqiyotini yangi bosqichga olib chiqdi." },
      { title: "Fransuz Inqilobi", subtitle: "Ozodlik va Tenglik", content: "Inson huquqlari deklaratsiyasi dunyo bo'ylab adolat va erkinlik g'oyalarini tarqatdi." },
      { title: "Geografik Kashfiyotlar", subtitle: "Yangi dunyo xaritasi", content: "Kolumb, Magellan va Vasko da Gama dengiz sayohatlari orqali qit'alarni bog'lashdi." },
      { title: "Mayya Sivilizatsiyasi", subtitle: "Amerika sirlari", content: "Tropik o'rmonlar qa'ridagi qadimgi taqvimlar, sirli piramidalar va iyerogliflar." },
      { title: "Xitoy Buyuk Devori", subtitle: "Tarixiy qalqon", content: "Miloddan avvalgi davrlardan boshlab qurilgan, minglab chaqirimga cho'zilgan ulkan mudofaa istehkomi." },
      { title: "Ikkinchi Jahon Urushi", subtitle: "Tinchlik qadri", content: "Insoniyat tarixidagi eng yirik fojia va davlatlar o'rtasida hamkorlik munosabatlari boshlanishi." },
      { title: "Kosmik poyga", subtitle: "Oyga qadam qo'yish", content: "Yuriy Gagarinning fazoga parvozi va Apollon missiyasining oy sirtidagi g'alabasi." },
      { title: "Xonliklar Davri", subtitle: "Markaziy Osiyo", content: "Buxoro amirligi, Xiva va Qo'qon xonliklarining madaniy va ijtimoiy hayoti." },
      { title: "Uchinchi renessans", subtitle: "Kelajakka poydevor", content: "O'zbekistonning ta'lim va innovatsion texnologiyalar orqali yosh avlodni tarbiyalash konsepsiyasi." },
      { title: "Vikinglar sarguzashtlari", subtitle: "Dengiz hukmdorlari", content: "Uzoq qirg'oqlarga uyushtirilgan jasur dengiz yurishlari va skandinav afsonalari." },
      { title: "Bobil osma bog'lari", subtitle: "Qadimiy mo'jiza", content: "Firat daryosi bo'yidagi baland terasali bog'lar va Hammurapi qonunlar to'plami." },
      { title: "Aleksandr Makedonskiy", subtitle: "Buyuk imperiya", content: "G'arbdan Hindistongacha bo'lgan hududlarni birlashtirgan harbiy sarkarda." },
      { title: "Bizans davri", subtitle: "Sharqiy Rim imperiyasi", content: "Ayo Sofiya ibodatxonasi va madaniyatlarning chorrahasi bo'lgan Konstantinopol." },
      { title: "Buyuk Depressiya", subtitle: "Iqtisodiy saboqlar", content: "1930-yillarda AQSh va Yevropani qamrab olgan va bank tizimini isloh qilgan inqiroz." },
      { title: "Yozuvning ixtiro qilinishi", subtitle: "Shumer mixxatlari", content: "Nutqni tosh va loy lavhalarga muhrlash orqali tarixiy xotirani saqlash." },
      { title: "Altamira rasmlari", subtitle: "Muzlik davri san'ati", content: "G'or devorlariga chizilgan ibtidoiy rasmlar va ajdodlarimiz dunyoqarashi." },
      { title: "Diplomatiya tarixi", subtitle: "Tinchlik shartnomalari", content: "Chegaralarni tinch yo'l bilan hal qilish va xalqaro muloqot tizimining shakllanishi." },
      { title: "Tarix saboqlari", subtitle: "Kelajak sirlari", content: "O'tmish xatolaridan to'g'ri xulosa chiqarish porloq kelajakning asosiy kafolatidir." }
    ],
    ru: [
      { title: "Египетские Пирамиды", subtitle: "Тайны Гизы и сокровища Фараонов", content: "Гигантские каменные пирамиды на протяжении тысячелетий вызывают искреннее восхищение инженеров." },
      { title: "Великий Шелковый Путь", subtitle: "Мост Культур", content: "В Самарканде и Бухаре началось великое слияние восточной мудрости и западной науки." },
      { title: "Древняя Греция", subtitle: "Колыбель Демократии", content: "Афинская система правления, философия и античная классика стали основой мировой цивилизации." },
      { title: "Римская Империя", subtitle: "Закон и Порядок", content: "Великие дороги, кодексы законов и непобедимые легионы оставили неизгладимый след в истории." },
      { title: "Рыцари Средневековья", subtitle: "Честь и Отвага", content: "Воины в нерушимых доспехах, штурмы замков и культура турниров." },
      { title: "Темуридский Ренессанс", subtitle: "Восточное Возрождение", content: "Быстрое развитие фундаментальных наук, астрономии и изящных искусств." },
      { title: "Эпоха Возрождения", subtitle: "Искусство и Гуманизм", content: "Произведения Леонардо да Винчи доказали безграничность человеческого гения." },
      { title: "Промышленная Революция", subtitle: "Эра Машин", content: "Появление парового двигателя и фабричного производства полностью изменило жизнь." },
      { title: "Французская Революция", subtitle: "Свобода и Равенство", content: "Декларация прав человека принесла миру новую надежду и свободу." },
      { title: "Географические Открытия", subtitle: "Новая Карта Мира", content: "Путешествия Колумба и Магеллана соединили ранее изолированные континенты." },
      { title: "Цивилизация Майя", subtitle: "Тайны Америки", content: "Древние каменные календари и ступенчатые храмы глубоко в тропических джунглях." },
      { title: "Великая Китайская Стена", subtitle: "Исторический Щит", content: "Уникальное оборонительное сооружение и самая длинная каменная стена в мире." },
      { title: "Вторая Мировая Война", subtitle: "Уроки и Мир", content: "Крупнейший конфликт в истории человечества и истинная ценность мирной жизни." },
      { title: "Покорение Космоса", subtitle: "Полет Человечества", content: "Полет Гагарина и высадка на Луну стали величайшей победой науки." },
      { title: "Эпоха Ханств", subtitle: "Центральная Азия", content: "Политические и экономические связи Бухарского, Хивинского и Кокандского ханств." },
      { title: "На пути к Возрождению", subtitle: "Новый Узбекистан", content: "Развитие национальной идеи, реформы образования и строительство прочного будущего." },
      { title: "Походы Викингов", subtitle: "Властелины Морей", content: "Легендарные скандинавские мореплаватели и их походы к далеким берегам Европы." },
      { title: "Древний Вавилон", subtitle: "Законы Хаммурапи", content: "Первый в мире письменный свод законов и чудо висячих садов Семирамиды." },
      { title: "Александр Македонский", subtitle: "Покоритель Мира", content: "Путь создания великой державы, объединившей культуру Запада и Востока." },
      { title: "Византийская Империя", subtitle: "Восточный Рим", content: "Стены Константинополя и шедевры христианского искусства." },
      { title: "Великая Депрессия", subtitle: "Кризис экономики", content: "Уроки краха мировой финансовой системы в 1930-х годах." },
      { title: "Изобретение Письменности", subtitle: "Клинопись и Папирус", content: "Начало сохранения знаний человечества для будущих поколений." },
      { title: "Рисунки Альтамиры", subtitle: "Первое Искусство", content: "Древние настенные рисунки охоты, оставленные первобытными людьми." },
      { title: "Мирные Договоры", subtitle: "История Дипломатии", content: "Важнейшие документы, остановившие войны и определившие границы государств." },
      { title: "Уроки Истории", subtitle: "Путь в Будущее", content: "Осознание прошлого помогает сохранить современный мир и процветание." }
    ],
    en: [
      { title: "Egyptian Pyramids", subtitle: "Secrets of Giza and Pharaoh Treasures", content: "Colossal stone pyramids have inspired and fascinated architects and historical scholars for thousands of years." },
      { title: "The Great Silk Road", subtitle: "Bridge of Civilizations", content: "The great intersection of Eastern wisdom and Western science in Samarkand and Bukhara." },
      { title: "Ancient Greece", subtitle: "Cradle of Democracy", content: "The intellectual foundation of philosophy, governance, and classical architecture." },
      { title: "The Roman Empire", subtitle: "Peace and Supremacy of Law", content: "Vast roads, organized legal frameworks, and undefeated armies left an immortal mark." },
      { title: "Medieval Knights", subtitle: "Honor and Valor", content: "Warriors clad in heavy plate armor protecting castles and competing in tourneys." },
      { title: "Timurid Renaissance", subtitle: "Eastern Awakening", content: "The swift rise of architecture, hard sciences, and astronomy across the grand continent." },
      { title: "The Renaissance", subtitle: "Art and Humanism", content: "Legendary works of Da Vinci and Michelangelo proved the infinite capability of human mind." },
      { title: "Industrial Revolution", subtitle: "Age of Machines", content: "The introduction of steam engines and massive factory complexes changed everyday life." },
      { title: "French Revolution", subtitle: "Liberty and Equality", content: "Declaration of Human Rights inspired nations worldwide to seek freedom." },
      { title: "Age of Discovery", subtitle: "Redrawing the Globe", content: "Historic adventures of Columbus, Magellan, and Da Gama connected distant lands." },
      { title: "Mayan Civilizations", subtitle: "Secrets of America", content: "Complex ancient calendars and stone pyramids built deep inside rainforests." },
      { title: "Great Wall of China", subtitle: "Historical Shield", content: "An incredible defense system and the longest stone wall structure on Earth." },
      { title: "World War II", subtitle: "True Cost of Peace", content: "The largest global conflict in history and lessons learned on protecting human life." },
      { title: "Conquering Space", subtitle: "Leap of Mankind", content: "Yuri Gagarin and Apollo Moon landings became ultimate markers of technological power." },
      { title: "The Khanates Epoch", subtitle: "Central Asia", content: "The historical, economical, and political developments of Bukhara, Khiva, and Kokand." },
      { title: "Path to Renaissance", subtitle: "Modern Transitions", content: "Promoting national ideals, modern educational systems, and constructing a stable future." },
      { title: "Viking Voyagers", subtitle: "Kings of the Cold Sea", content: "Legendary explorers and their legendary wooden dragon boats." },
      { title: "Ancient Babylon", subtitle: "Hammurabi Code", content: "The first recorded written laws and the majestic hanging gardens marvel." },
      { title: "Alexander the Great", subtitle: "Universal Conqueror", content: "The creation of a massive empire bridging European and Asian cultures." },
      { title: "Byzantine Empire", subtitle: "Eastern Rome", content: "The strong walls of Constantinople and masterpiece orthodox mosaics." },
      { title: "Great Depression", subtitle: "Financial Breakdown", content: "Lessons learned from the catastrophic breakdown of the global economy in 1930s." },
      { title: "Invention of Writing", subtitle: "Cuneiform and Papyrus", content: "The start of recording human memories for future generations." },
      { title: "Altamira Cave Painting", subtitle: "Prehistoric Art", content: "Primitive drawings of red bisons and hunting triumphs." },
      { title: "Peace Treaties", subtitle: "Diplomacy History", content: "Historical documents that ended grand conflicts and set global borders." },
      { title: "Lessons of History", subtitle: "Building Tomorrow", content: "Learning from previous errors avoids repeating them, safeguarding peace." }
    ]
  },
  arxitektura: {
    uz: generateHelperList("arxitektura", "Me'morchilik", "Arxitektura asarlari, uylar loyihasi va shahar me'moriy qiyofasi.", "uz"),
    ru: generateHelperList("arxitektura", "Архитектура", "Архитектурные шедевры, проектирование зданий и градостроительство.", "ru"),
    en: generateHelperList("arxitektura", "Architecture", "Architectural masterpieces, building designs and urban environments.", "en")
  },
  biznes: {
    uz: generateHelperList("biznes", "Biznes", "Startaplar moliya investitsiyalari, loyihalar va marketing strategiyasi.", "uz"),
    ru: generateHelperList("biznes", "Бизнес", "Стартапы, финансовые инвестиции, проекты и маркетинговые стратегии.", "ru"),
    en: generateHelperList("biznes", "Business", "Startups, financial investments, projects and marketing strategies.", "en")
  },
  medicina: {
    uz: generateHelperList("medicina", "Tibbiyot", "Inson salomatligi, tibbiyot sohasidagi texnologiyalar va nevrologiya fani.", "uz"),
    ru: generateHelperList("medicina", "Медицина", "Здоровье человека, технологии в медицине и медицинские науки.", "ru"),
    en: generateHelperList("medicina", "Medicine", "Human health, technology in medicine and medical sciences.", "en")
  },
  fanlar: {
    uz: generateHelperList("fanlar", "Fan olami", "Fizika, astronomiya, kimyo va koinotni tadqiq etish yutuqlari.", "uz"),
    ru: generateHelperList("fanlar", "Наука", "Достижения в физике, астрономии, химии и космических исследованиях.", "ru"),
    en: generateHelperList("fanlar", "Sciences", "Achievements in physics, astronomy, chemistry and space research.", "en")
  },
  sport: {
    uz: generateHelperList("sport", "Sport", "Sog'lom turmush tarzi, olimpiada, intizom va chempionlik mezonlari.", "uz"),
    ru: generateHelperList("sport", "Спорт", "Здоровый образ жизни, олимпиада, дисциплина и критерии чемпионства.", "ru"),
    en: generateHelperList("sport", "Sport", "Healthy lifestyle, Olympics, discipline and championship criteria.", "en")
  },
  tabiyat: {
    uz: generateHelperList("tabiyat", "Tabiat", "Ekologiya, atrof-muhitni asrash, o'simlik va hayvonot olami go'zalligi.", "uz"),
    ru: generateHelperList("tabiyat", "Природа", "Экология, сохранение окружающей среды, красота флоры и фауны.", "ru"),
    en: generateHelperList("tabiyat", "Nature", "Ecology, environmental preservation, beautiful flora and fauna.", "en")
  },
  qurilish: {
    uz: generateHelperList("qurilish", "Qurilish", "Infratuzilmalar yaratish, yangi binolar, og'ir sanoat va aqlli shahar loyihalari.", "uz"),
    ru: generateHelperList("qurilish", "Строительство", "Создание инфраструктуры, новые здания, тяжелая промышленность и умные города.", "ru"),
    en: generateHelperList("qurilish", "Construction", "Creating infrastructure, new buildings, heavy industries and smart city plans.", "en")
  }
};

// Generates beautiful titles and details if the category is not hardcoded item-by-item
function generateHelperList(catId: string, prefix: string, desc: string, lang: Language): { title: string; subtitle: string; content: string }[] {
  const result: { title: string; subtitle: string; content: string }[] = [];
  const topicsUz = [
    "Muqaddima va Konsept",
    "Mukammal Yondashuv",
    "Asosiy Muammolar tahlili",
    "Innovatsion Texnologiyalar",
    "Batafsil Rejalashtirish",
    "Xalqaro Tajriba",
    "Sifat Standartlari va Nazorati",
    "Moliyaviy hisob-kitoblar va Investitsiya",
    "Inson Resurslari va Jamoa",
    "Xavfsizlik choralari asoslari",
    "Kutilgan Natijalar ko'rsatkichi",
    "Yashil uslublar joriy etish",
    "Strategik Harakatlar dasturi",
    "Yaratuvchanlik sirlari",
    "Raqamli vositalardan foydalanish",
    "Xatarlarni baholash metodologiyasi",
    "Andoza asoslari va andozalashtirish",
    "Zarur resurslarni mobilizatsiya qilish",
    "Mijoz va Jamiyat munosabatlari",
    "Sinovdan o'tkazish tajribalari",
    "Muvaffaqiyat kaliti va tahlil",
    "Estetik qiymat berish",
    "Istiqbolli Rejalar (2026-2030)",
    "Haqiqiy holat ko'rinishi",
    "Xulosa va Yakuniy hisobot"
  ];

  const topicsRu = [
    "Введение и Основная Концепция",
    "Идеальный Подход к делу",
    "Анализ ключевых проблем и вызовов",
    "Инновационные Технологии и методы",
    "Детальное Репланирование",
    "Международный Опыт и стандарты",
    "Контроль Качества и надежности",
    "Финансовые Расчеты и Инвестиции",
    "Человеческий Капитал и Команда",
    "Основные Меры Безопасности",
    "Показатели Ожидаемых Результатов",
    "Внедрение Зеленых Стандартов",
    "Программа Стратегического Развития",
    "Секреты Креативного Подхода",
    "Использование Цифровых Сервисов",
    "Методология Оценки Рисков",
    "Теоретические Основы Шаблона",
    "Мобилизация Ресурсов и Систем",
    "Взаимодействие с Клиентами",
    "Эксперименты и Тестирование",
    "Ключ к Успеху и Глубокий Анализ",
    "Эстетическая Ценность Проекта",
    "Перспективные Планы (2026-2030)",
    "Реальные Практические Кейсы",
    "Заключение и Финальный Отчет"
  ];

  const topicsEn = [
    "Introduction and Core Concept",
    "Perfect Professional Approach",
    "Core Challenges & Pain Points",
    "Innovative Tech Integrations",
    "Detailed Project Scheduling",
    "Global Standards & Best Practices",
    "Quality Control Framework",
    "Financial Planning & Calculations",
    "Human Capital & Team Building",
    "Essential Security Measures",
    "Expected Conversion Metrics",
    "Adopting Sustainable Green Tech",
    "Strategic Evolution Mapping",
    "Secrets of Creative Delivery",
    "Utilizing Digital Ecosystems",
    "Risk Assessment Methodology",
    "Theoretical Template Foundations",
    "Resource Shifting & Mobilization",
    "Client Response & Communication",
    "Pilots, Tests and Verification",
    "Key to Success and Analytics",
    "Aesthetic Integrity of Solutions",
    "Future Directions (2026-2030)",
    "Real-world Case Studies",
    "Conclusion and Executive Summary"
  ];

  const list = lang === "uz" ? topicsUz : lang === "ru" ? topicsRu : topicsEn;

  for (let i = 0; i < 25; i++) {
    const title = list[i] || `${prefix} Slide No. ${i + 1}`;
    let subtitle = "";
    let content = "";

    if (lang === "uz") {
      subtitle = `${prefix} tahlili &bull; Bo'lim ${i + 1}`;
      content = `Ushbu qism ${prefix.toLowerCase()} sohasini chuqur tahlil qilishga bag'ishlangan. Mazkur animatsion andoza orqali siz professional ma'lumotlarni slaydga joylashingiz mumkin. ${desc}`;
    } else if (lang === "ru") {
      subtitle = `Анализ ${prefix.toLowerCase()} &bull; Раздел ${i + 1}`;
      content = `Эта часть посвящена детальному изучению темы ${prefix.toLowerCase()}. С помощью подготовленного шаблона вы сможете элегантно представить материалы перед аудиторией. ${desc}`;
    } else {
      subtitle = `${prefix} Analysis &bull; Section ${i + 1}`;
      content = `This section provides an analytical deep dive into ${prefix.toLowerCase()} principles. By using this clean styled slide, your presentation message will reach your audience with clarity. ${desc}`;
    }

    result.push({
      title,
      subtitle,
      content
    });
  }

  return result;
}

// Compiles count dynamically in cycling sequence of colors and layouts
export function generateCustomSlidesForCategory(lang: Language, category: CategoryId, count: number): Slide[] {
  const dataset = SUPPLEMENTARY_DATA[category] || SUPPLEMENTARY_DATA["sayohat"];
  const listInLang = dataset[lang] || dataset["en"];

  const layouts: Slide["layout"][] = ["simple", "hero", "split", "grid", "quote"];
  const colors = ["violet", "indigo", "rose", "emerald", "sky", "amber", "cyan"];

  const compiledSlides: Slide[] = [];

  for (let i = 0; i < count; i++) {
    const dataItem = listInLang[i % listInLang.length];
    
    compiledSlides.push({
      id: `generated-${category}-${i}-${Date.now()}`,
      title: dataItem.title,
      subtitle: dataItem.subtitle,
      content: dataItem.content,
      layout: layouts[i % layouts.length],
      accentColor: colors[i % colors.length]
    });
  }

  return compiledSlides;
}
