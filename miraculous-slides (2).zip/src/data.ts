import { Category, Presentation } from "./types";

export const STATS_ITEMS = [
  { value: "150", label: "Intervyu Tahlili", desc: "Mijoz ehtiyojlari o'rganilgan" },
  { value: "250+", label: "Maxfiy Sayt muammolari", desc: "Xavfsizlik loyihalari" },
  { value: "100", label: "Inobatga olingan parametrlar", desc: "Slayd strukturalari" },
  { value: "82", label: "Prezentatsiya Vario rejimlari", desc: "Animatsiya uslublari" },
  { value: "500K+", label: "Ijobiy fikrlar", desc: "Butun dunyo bo'ylab" },
  { value: "8+", label: "Yaratilgan ruknlar", desc: "Asosiy mavzular" },
  { value: "350+", label: "Tayyor Andoza Slaydlar", desc: "Darhol foydalanishga tayyor" }
];

export const SLIDER_CARDS = [
  { index: "1", title: "Sayohat", desc: "Yangi ufqlar va unutilmas sarguzashtlar olami", num: "01" },
  { index: "2", title: "Tarix", desc: "Sivilizatsiyalar silsilasi va o'tmish saboqlari", num: "02" },
  { index: "3", title: "Arxitektura & Qurilish", desc: "Me'morchilik durdonalari va aqlli uylar", num: "03" },
  { index: "4", title: "Biznes", desc: "Sarmoya, startaplar va moliyaviy muvaffaqiyat", num: "04" },
  { index: "5", title: "Va boshqalar", desc: "Meditsina, sport, fan va tabiat mo'jizalari", num: "05" }
];

export const CATEGORIES_LIST: Category[] = [
  {
    id: "sayohat",
    label: "Travel",
    uzLabel: "SAYOHAT",
    iconName: "Compass",
    description: "Sayohat g'oyalari, turizm, dunyo kashfiyotlari va sarguzashtlar.",
    themeColor: "from-purple-600 to-indigo-600",
    glowColor: "rgba(139, 92, 246, 0.5)",
    templates: [
      { id: "s1", title: "Sayohat San'ati", subtitle: "Toshkent - Yangi Chegaralar", content: "Sayohat qilish - bu nafaqat masofalarni bosib o'tish, balki ruhiy rivojlanish va yangi do'stlar orttirishdir.", layout: "hero", accentColor: "violet" },
      { id: "s2", title: "Yovvoyi Savanna", subtitle: "Keniyada unutilmas kunlar", content: "Afrika tabiati va uning to'lib-toshgan energiyasi har bir sayohatchining orzusidagi dunyodir.", layout: "split", accentColor: "emerald" },
      { id: "s3", title: "Yevropa Nafasi", subtitle: "Tarix ko'chalari", content: "Gotika uslubidagi ibodatxonalar va shinam qahvaxonalar sizni sehrli dunyoga chorlaydi.", layout: "grid", accentColor: "amber" }
    ]
  },
  {
    id: "tarix",
    label: "History",
    uzLabel: "TARIX",
    iconName: "BookOpen",
    description: "Qadimgi dunyo sivilizatsiyalari, imperiyalar va tarixiy meroslar.",
    themeColor: "from-amber-600 to-purple-800",
    glowColor: "rgba(245, 158, 11, 0.5)",
    templates: [
      { id: "h1", title: "Misr Ehromlari", subtitle: "Giza sirlari va Fir'avn xazinalari", content: "Ulkan toshlardan qurilgan ehromlar ming yillar davomida dunyo me'morlarini hayratda qoldirib kelmoqda.", layout: "hero", accentColor: "amber" },
      { id: "h2", title: "Buyuk Ipak Yo'li", subtitle: "Madaniyatlar ko'prigi", content: "Samarqand va Buxoro chorrahasida Sharq sirlari va G'arb fanining uyg'unlashuvi boshlangan.", layout: "split", accentColor: "indigo" }
    ]
  },
  {
    id: "arxitektura",
    label: "Architecture",
    uzLabel: "ARXITEKTURA",
    iconName: "DraftingCompass",
    description: "Loyihalash, dizayn, gotika, modernizm va interyer dizayni.",
    themeColor: "from-blue-600 to-cyan-500",
    glowColor: "rgba(59, 130, 246, 0.5)",
    templates: [
      { id: "a1", title: "Futuristik Me'morchilik", subtitle: "Eko-barqaror uylar", content: "Kelajak binolari tabiiy yorug'likdan maksimal foydalanishga rejalashtirilgan aqlli tizimlarga asoslanadi.", layout: "hero", accentColor: "sky" },
      { id: "a2", title: "Parametrik Loyihalar", subtitle: "Zaha Hadid maktabi", content: "Tekis chiziqlarning yo'qligi va tabiiy suyuq shakllar zamonaviy jahon dizaynini belgilaydi.", layout: "split", accentColor: "violet" }
    ]
  },
  {
    id: "biznes",
    label: "Business",
    uzLabel: "BIZNES",
    iconName: "TrendingUp",
    description: "Startaplar, investitsion taqdimotlar, moliya va bozor tahlili.",
    themeColor: "from-violet-700 to-emerald-600",
    glowColor: "rgba(16, 185, 129, 0.5)",
    templates: [
      { id: "b1", title: "Raqamli Muvaffaqiyat", subtitle: "Eksponental O'sish Strategiyasi", content: "Foydalanuvchi interfeysi (UI) va foydalanuvchi tajribasiga (UX) investitsiya kiritish brend sodiqligini 400% oshiradi.", layout: "hero", accentColor: "violet" },
      { id: "b2", title: "Pitch Deck and Strategy", subtitle: "Pitch and Grow", content: "Loyihangiz muvaffaqiyati aniq belgilangan muammoni topish va bozor qanchalik kengligini sarmoyadorlarga ko'rsatishda.", layout: "split", accentColor: "emerald" },
      { id: "b3", title: "Moliya Bozorlari", subtitle: "Risklarni minimallashtirish", content: "Diversifikatsiya va prognozlash barcha davrlarda eng mustahkam biznes poydevoridir.", layout: "grid", accentColor: "indigo" }
    ]
  },
  {
    id: "medicina",
    label: "Medicine",
    uzLabel: "MEDICINA",
    iconName: "Activity",
    description: "Salomatlik, nevrologiya, zamonaviy tibbiyot va sog'lom turmush tarzi.",
    themeColor: "from-rose-600 to-pink-500",
    glowColor: "rgba(244, 63, 94, 0.5)",
    templates: [
      { id: "m1", title: "Yurak Salomatligi", subtitle: "Profilaktika tahlillari", content: "Yurak qon-tomir tizimini asrash jismoniy mashqlar, asabni tinchlantirish va sog'lom taomlardan boshlanadi.", layout: "hero", accentColor: "rose" },
      { id: "m2", title: "Sun'iy Intellekt va Neyrojarrohlik", subtitle: "Texnologik Tibbiyot", content: "Kompyuter vizualizatsiyasi va mikrosuratlar murakkab operatsiyalarda xatoliklarni 0.1% gacha qisqartirdi.", layout: "split", accentColor: "rose" }
    ]
  },
  {
    id: "fanlar",
    label: "Sciences",
    uzLabel: "FANLAR",
    iconName: "Atom",
    description: "Fizika, astronomiya, biologiya va kimyo sohasidagi yutuqlar.",
    themeColor: "from-indigo-600 to-teal-500",
    glowColor: "rgba(99, 102, 241, 0.5)",
    templates: [
      { id: "f1", title: "Kvant Superkompyuterlar", subtitle: "Yangi hisoblash erasi", content: "Kvant hisob-kitoblari an'anaviy tranzistorlar bajara olmaydigan trillionlab amallarni bir soniyada yakunlaydi.", layout: "hero", accentColor: "indigo" },
      { id: "f2", title: "Koinot qa'riga sayohat", subtitle: "James Webb kashfiyotlari", content: "Ilk koinot yulduzlari va uzoq ekzosayyoralarda hayot belgilarini izlash yanada osonlashdi.", layout: "split", accentColor: "cyan" }
    ]
  },
  {
    id: "sport",
    label: "Sport",
    uzLabel: "SPORT",
    iconName: "Award",
    description: "Dinamik jismoniy mashqlar, olimpiya o'yinlari va sog'lom hayot.",
    themeColor: "from-amber-500 to-orange-600",
    glowColor: "rgba(245, 158, 11, 0.5)",
    templates: [
      { id: "sp1", title: "Olimpiya Cho'qqisi", subtitle: "Matonat va g'alaba hissi", content: "Chempionlik sirlari - doimiy intizom, to'g'ri reabilitatsiya va psixologik chidamlilikdan iborat.", layout: "hero", accentColor: "amber" }
    ]
  },
  {
    id: "tabiyat",
    label: "Nature",
    uzLabel: "TABIYAT",
    iconName: "Trees",
    description: "Atrof-muhitni muhofaza qilish, hayvonot olami va o'simliklar.",
    themeColor: "from-emerald-500 to-teal-700",
    glowColor: "rgba(16, 185, 129, 0.5)",
    templates: [
      { id: "t1", title: "Yashil Sayyora", subtitle: "Eco Energy va Iqlim", content: "Yashil energiyaning rivojlanishi karbonat chiqindilarini keskin kamaytirib jannatmakon tabiatni asraydi.", layout: "hero", accentColor: "emerald" }
    ]
  },
  {
    id: "qurilish",
    label: "Construction",
    uzLabel: "QURILISH",
    iconName: "Construction",
    description: "Og'ir qurilish materiallari, muhandislik loyihalari va aqlli shahar.",
    themeColor: "from-slate-700 to-blue-900",
    glowColor: "rgba(71, 85, 105, 0.5)",
    templates: [
      { id: "q1", title: "Aqlli Shahar va Infratuzilma", subtitle: "Kelajak megapolislari", content: "Yo'l harakati xavfsizligi, quyosh energiyali ko'chalar va avtomatlashgan uylar - hammasi uyg'unlikda.", layout: "hero", accentColor: "indigo" }
    ]
  }
];

export const STATIC_PRESENTATIONS: Presentation[] = [
  {
    id: "pres-1",
    title: "Sayohat va O'zlikni kashf qilish",
    category: "sayohat",
    createdAt: "2026-06-07",
    slides: CATEGORIES_LIST[0].templates
  },
  {
    id: "pres-2",
    title: "Biznesni rivojlantirish 2026",
    category: "biznes",
    createdAt: "2026-06-06",
    slides: CATEGORIES_LIST[3].templates
  }
];
