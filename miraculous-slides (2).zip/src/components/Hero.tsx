import React from "react";
import { Sparkles, ArrowRight, Play } from "lucide-react";
import { motion } from "motion/react";
import { Language, TRANSLATIONS } from "../translations";

interface HeroProps {
  onCreateClick: () => void;
  lang: Language;
}

export default function Hero({ onCreateClick, lang }: HeroProps) {
  const t = TRANSLATIONS[lang];

  return (
    <section className="relative overflow-hidden pt-12 pb-24 md:pt-20 md:pb-32 bg-[#09090b]">
      
      {/* Background Bento Orbs */}
      <div className="absolute top-1/4 left-1/2 -translate-x-1/2 -translate-y-1/2 h-[500px] w-[500px] rounded-full bg-teal-900/10 blur-[130px] pointer-events-none" />
      <div className="absolute top-1/3 right-10 h-[300px] w-[300px] rounded-full bg-teal-600/5 blur-[90px] pointer-events-none" />
      
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 relative z-10 grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
        
        {/* Left column: Text Content */}
        <div className="lg:col-span-7 text-left space-y-6">
          
          {/* Accent dot indicator styled after Bento skills tag */}
          <div className="inline-flex items-center space-x-2 py-1.5 px-3 rounded-full bg-teal-950/40 border border-teal-500/20">
            <span className="flex h-2 w-2 relative">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-teal-400 opacity-75"></span>
              <span className="relative inline-flex rounded-full h-2 w-2 bg-teal-500"></span>
            </span>
            <span className="text-xs font-bold text-teal-400 tracking-wide font-mono uppercase">
              {lang === "uz" ? "Yangi: Sun'iy Intellektli Slaydlar" : lang === "ru" ? "Новинка: ИИ-Слайды" : "New: AI-Powered Slides"}
            </span>
          </div>

          {/* Majestic Hero Headline */}
          <h2 className="text-4xl sm:text-5xl md:text-6xl font-extrabold text-white leading-tight tracking-tight uppercase font-sans">
            {t.heroTitle1} <br />
            <span className="bg-gradient-to-r from-teal-400 via-sky-400 to-indigo-500 bg-clip-text text-transparent">
              {t.heroTitle2}
            </span>
          </h2>

          {/* Subtitle / Description */}
          <p className="max-w-xl text-slate-400 text-sm sm:text-base leading-relaxed">
            {t.heroDesc}
          </p>

          {/* CTA Button Group styled perfectly from Bento layout */}
          <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-4 pt-4">
            <button
              onClick={onCreateClick}
              className="group relative flex items-center justify-center space-x-2 px-8 py-3.5 bg-white text-black rounded-full font-bold text-xs uppercase tracking-wider shadow-lg hover:bg-slate-200 transition-all cursor-pointer"
              id="hero-generate-btn"
            >
              <Sparkles className="h-4.5 w-4.5 text-teal-650 animate-spin" />
              <span>{lang === "uz" ? "O'z mo'jizangni yarat" : lang === "ru" ? "Создайте свое чудо" : "Create your masterpiece"}</span>
              <ArrowRight className="h-4 w-4 transition-transform group-hover:translate-x-1" />
            </button>

            <button
              onClick={onCreateClick}
              className="flex items-center justify-center space-x-2 px-7 py-3.5 rounded-full border border-slate-800 bg-[#121214] text-xs font-bold uppercase tracking-wider text-slate-350 hover:text-white hover:border-slate-700 transition-all cursor-pointer"
            >
              <Play className="h-3.5 w-3.5 fill-current text-teal-400" />
              <span>{t.heroBtn}</span>
            </button>
          </div>

        </div>

        {/* Right column: 3D Glowing Glass Steps Staircase & Pyramid */}
        <div className="lg:col-span-5 flex justify-center">
          <div className="relative h-[380px] w-full max-w-[340px] md:max-w-[400px] flex items-center justify-center">
            
            {/* Ambient Background Light Circle */}
            <div className="absolute inset-0 bg-gradient-to-tr from-indigo-500/10 to-sky-500/10 rounded-full blur-[60px] pointer-events-none" />

            {/* Custom 3D Perspective container with stair layout */}
            <div 
              className="relative w-full h-full flex flex-col items-center justify-end pb-12"
              style={{ perspective: "1000px" }}
            >
              
              {/* Glowing Glass Pyramid Headpiece at the vertex */}
              <div 
                className="absolute top-10 transform scale-110 animate-pulse duration-3000"
                style={{ transformStyle: "preserve-3d" }}
              >
                <div className="relative h-18 w-18">
                  {/* Floating Pyramid sides */}
                  <div className="absolute inset-0 bg-gradient-to-b from-indigo-500/50 via-sky-600/40 to-transparent border-t border-indigo-400/80 rounded-bl-full rounded-tr-full rotate-45 transform skew-x-12 shadow-[0_0_30px_rgb(99,102,241)]" />
                  <div className="absolute inset-0 bg-gradient-to-r from-indigo-600/40 via-sky-500/30 to-transparent border-t border-sky-400/40 rounded-br-full rounded-tl-full -rotate-45 transform -skew-y-12" />
                  <div className="absolute -top-2 left-6 h-3 w-3 bg-white rounded-full blur-xs animate-ping" />
                </div>
              </div>

              {/* 3D Glass staircase levels styled beautifully with Indigo/Cyan theme */}
              {[
                { y: -30, x: 50, scale: 0.70, delay: 0.6, rotate: 20 },
                { y: -65, x: 35, scale: 0.75, delay: 0.5, rotate: 15 },
                { y: -100, x: 20, scale: 0.82, delay: 0.4, rotate: 10 },
                { y: -135, x: 5, scale: 0.88, delay: 0.3, rotate: 5 },
                { y: -170, x: -10, scale: 0.94, delay: 0.2, rotate: 0 },
                { y: -205, x: -25, scale: 1.0, delay: 0.1, rotate: -5 },
                { y: -240, x: -40, scale: 1.06, delay: 0, rotate: -10 },
              ].map((stair, index) => (
                <div
                  key={index}
                  className="absolute w-24 h-12 rounded-lg transition-transform hover:shadow-indigo-500/40 cursor-pointer"
                  style={{
                    bottom: `${index * 38 + 20}px`,
                    transform: `translateX(${stair.x * 1.5}px) scale(${stair.scale}) rotateX(60deg) rotateZ(-35deg) translateY(${stair.y * 0.1}px)`,
                    background: "rgba(99, 102, 241, 0.22)",
                    border: "1px solid rgba(129, 140, 248, 0.6)",
                    boxShadow: "0 8px 32px 0 rgba(79, 70, 229, 0.35), inset 0 2px 8px rgba(255, 255, 255, 0.35)",
                    backdropFilter: "blur(8px)",
                  }}
                  id={`staircase-level-${index}`}
                >
                  {/* Glowing core representing internal refraction */}
                  <div className="absolute inset-1.5 rounded bg-gradient-to-br from-white/30 to-transparent pointer-events-none" />
                  <div className="absolute -bottom-1 left-2 right-2 h-1 bg-gradient-to-r from-indigo-400 to-sky-400 blur-xs rounded-full opacity-70" />
                </div>
              ))}

              {/* Glowing floor projection */}
              <div 
                className="absolute w-52 h-20 rounded-full blur-xl pointer-events-none opacity-60"
                style={{
                  bottom: "-6px",
                  background: "radial-gradient(circle, rgba(99,102,241,0.5) 0%, rgba(56,189,248,0.1) 70%, transparent 100%)",
                  transform: "rotateX(75deg)"
                }}
              />

            </div>

          </div>
        </div>

      </div>
    </section>
  );
}
