import React from "react";
import { Crown, LogOut, Sparkles, CreditCard, Globe } from "lucide-react";
import { User as UserType } from "../types";
import { Language, TRANSLATIONS } from "../translations";
import { Logo } from "./Logo";

interface HeaderProps {
  user: UserType | null;
  onOpenLogin: () => void;
  onOpenPayment: () => void;
  onLogout: () => void;
  activeTab: string;
  setActiveTab: (tab: string) => void;
  lang: Language;
  setLang: (lang: Language) => void;
}

export default function Header({
  user,
  onOpenLogin,
  onOpenPayment,
  onLogout,
  activeTab,
  setActiveTab,
  lang,
  setLang,
}: HeaderProps) {
  const t = TRANSLATIONS[lang];

  return (
    <header className="sticky top-0 z-40 w-full border-b border-zinc-900 bg-[#09090b]/95 backdrop-blur-md">
      <div className="mx-auto flex max-w-7xl h-20 flex-col justify-center px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between">
          
          {/* Sleek Glowing Logo matching the uploaded M graphic */}
          <div 
            onClick={() => setActiveTab("landing")}
            className="flex cursor-pointer items-center space-x-2.5 text-left focus:outline-none shrink-0 animate-fade-in"
            id="brand-logo-btn"
          >
            <Logo size={40} className="hover:scale-105 transition-transform" />
            <div>
              <h1 className="text-sm font-black tracking-tight text-white uppercase sm:text-base">
                {t.logoTitle}
                <span className="block text-[8px] font-bold tracking-widest text-teal-400 -mt-0.5 font-mono">
                  ANIMATED SHABLONS
                </span>
              </h1>
            </div>
          </div>

          {/* Desktop Tab Navigation styled with Bento theme tags */}
          <nav className="hidden md:flex items-center space-x-1.5">
            <button
              onClick={() => setActiveTab("landing")}
              className={`px-3 py-1.5 text-xs font-bold rounded-full transition-all cursor-pointer ${
                activeTab === "landing"
                  ? "bg-teal-500 text-black shadow-[0_0_10px_rgba(20,184,166,0.3)]"
                  : "text-zinc-400 hover:text-white hover:bg-zinc-900"
              }`}
              id="nav-tab-landing"
            >
              {t.home}
            </button>
            
            <button
              onClick={() => setActiveTab("editor")}
              className={`relative px-3 py-1.5 text-xs font-bold rounded-full transition-all flex items-center space-x-1 cursor-pointer ${
                activeTab === "editor"
                  ? "bg-teal-500 text-black shadow-[0_0_10px_rgba(20,184,166,0.3)]"
                  : "text-zinc-400 hover:text-white hover:bg-zinc-900"
              }`}
              id="nav-tab-editor"
            >
              <span>{t.openButton}</span>
              <Sparkles className="h-3 w-3 text-amber-300 animate-pulse" />
            </button>

            <button
              onClick={() => setActiveTab("social")}
              className={`px-3 py-1.5 text-xs font-bold rounded-full transition-all cursor-pointer ${
                activeTab === "social"
                  ? "bg-teal-500 text-black shadow-[0_0_10px_rgba(20,184,166,0.3)]"
                  : "text-zinc-400 hover:text-white hover:bg-zinc-900"
              }`}
              id="nav-tab-social"
            >
              {t.socials}
            </button>
          </nav>

          {/* Action Buttons & Profile & Language Switcher */}
          <div className="flex items-center space-x-2.5">
            {/* Language Selection Badge */}
            <div className="flex items-center space-x-1 bg-zinc-900/80 border border-zinc-800 rounded-lg p-1">
              <Globe className="h-3.5 w-3.5 text-teal-400 ml-1 block sm:inline shrink-0" />
              <select
                className="bg-transparent text-[11px] font-bold text-zinc-300 focus:outline-none cursor-pointer pr-1"
                value={lang}
                onChange={(e) => setLang(e.target.value as Language)}
                id="language-selector-badge"
              >
                <option value="uz" className="bg-[#09090b] text-white">UZB</option>
                <option value="ru" className="bg-[#09090b] text-white">RUS</option>
                <option value="en" className="bg-[#09090b] text-white">ENG</option>
              </select>
            </div>

            {!user ? (
              <div className="flex items-center space-x-1.5 shrink-0">
                <button
                  onClick={onOpenLogin}
                  className="px-3.5 py-1.5 text-xs font-extrabold bg-teal-400 text-black hover:bg-teal-350 rounded-lg cursor-pointer transition-all uppercase tracking-wider shadow-[0_0_15px_rgba(20,184,166,0.3)]"
                  id="header-login-btn"
                >
                  {t.login}
                </button>
              </div>
            ) : (
              <div className="flex items-center space-x-1.5 shrink-0">
                <div className="flex items-center space-x-1.5 px-2.5 py-1.5 rounded-lg bg-zinc-900/60 border border-zinc-800">
                  <div className="h-4.5 w-4.5 rounded-md bg-teal-400 flex items-center justify-center text-[9px] font-black text-black">
                    {user.name.charAt(0).toUpperCase()}
                  </div>
                  <span className="hidden lg:inline text-[11px] font-bold text-zinc-300 font-mono">
                    {user.name}
                  </span>
                </div>
                
                <button
                  onClick={onLogout}
                  className="p-2 text-zinc-500 hover:text-red-400 rounded-lg hover:bg-zinc-900 transition-all cursor-pointer shrink-0"
                  title={t.logout}
                  id="header-logout-btn"
                >
                  <LogOut className="h-4 w-4" />
                </button>
              </div>
            )}
          </div>
        </div>

        {/* Mobile Navigation Bar (Always visible & premium looking on smaller screens) */}
        <div className="flex md:hidden items-center justify-around border-t border-zinc-900/60 mt-2.5 pt-1.5 pb-0.5 overflow-x-auto gap-0.5 no-scrollbar shrink-0">
          <button
            onClick={() => setActiveTab("landing")}
            className={`px-3 py-1 text-[11px] font-black uppercase tracking-wider rounded-md transition-all shrink-0 ${
              activeTab === "landing"
                ? "bg-teal-950/60 border border-teal-500/35 text-teal-300"
                : "text-zinc-500 hover:text-white"
            }`}
          >
            {t.home}
          </button>
          
          <button
            onClick={() => setActiveTab("editor")}
            className={`px-3 py-1 text-[11px] font-black uppercase tracking-wider rounded-md transition-all flex items-center space-x-1 shrink-0 ${
              activeTab === "editor"
                ? "bg-teal-950/60 border border-teal-500/35 text-teal-300"
                : "text-zinc-500 hover:text-white"
            }`}
          >
            <span>{t.openButton}</span>
            <Sparkles className="h-2.5 w-2.5 text-amber-300 animate-pulse" />
          </button>

          <button
            onClick={() => setActiveTab("social")}
            className={`px-3 py-1 text-[11px] font-black uppercase tracking-wider rounded-md transition-all shrink-0 ${
              activeTab === "social"
                ? "bg-teal-950/60 border border-teal-500/35 text-teal-300"
                : "text-zinc-500 hover:text-white"
            }`}
          >
            {t.socials}
          </button>
        </div>

      </div>
    </header>
  );
}

