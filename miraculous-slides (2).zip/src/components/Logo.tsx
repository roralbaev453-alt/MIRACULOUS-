import React from "react";

interface LogoProps {
  className?: string;
  size?: number;
}

export function Logo({ className = "", size = 36 }: LogoProps) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 120 120"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      className={`${className} select-none`}
    >
      <defs>
        {/* Purple gradient for the left feathered wing */}
        <linearGradient id="purple-wing-grad" x1="10" y1="20" x2="60" y2="100" gradientUnits="userSpaceOnUse">
          <stop offset="0%" stopColor="#d946ef" /> {/* Fuchsia 500 */}
          <stop offset="50%" stopColor="#a855f7" /> {/* Purple 500 */}
          <stop offset="100%" stopColor="#6366f1" /> {/* Indigo 500 */}
        </linearGradient>

        {/* Blue/Cyan gradient for the right solid wing */}
        <linearGradient id="blue-wing-grad" x1="60" y1="20" x2="110" y2="100" gradientUnits="userSpaceOnUse">
          <stop offset="0%" stopColor="#38bdf8" /> {/* Sky 400 */}
          <stop offset="50%" stopColor="#0ea5e9" /> {/* Sky 500 */}
          <stop offset="100%" stopColor="#2563eb" /> {/* Blue 600 */}
        </linearGradient>

        {/* Glow filters for awesome futuristic bento aesthetic */}
        <filter id="logo-glow" x="-20%" y="-20%" width="140%" height="140%">
          <feGaussianBlur stdDeviation="4" result="blur" />
          <feComposite in="SourceGraphic" in2="blur" operator="over" />
        </filter>
      </defs>

      <g filter="url(#logo-glow)">
        {/* LEFT PART: 5 layered waves in 3D overlapping wing style (replicating the image) */}
        {/* Feather 1 (Top-most) */}
        <path
          d="M 54,28 C 42,22 28,24 18,34 C 15,37 18,40 23,38 C 32,34 43,33 52,36 C 55,37 56,33 54,28 Z"
          fill="url(#purple-wing-grad)"
          opacity="0.95"
        />

        {/* Feather 2 */}
        <path
          d="M 55,41 C 41,36 26,38 16,50 C 13,54 16,56 21,53 C 30,48 41,47 51,50 C 54,51 56,46 55,41 Z"
          fill="url(#purple-wing-grad)"
          opacity="0.9"
        />

        {/* Feather 3 */}
        <path
          d="M 56,55 C 40,51 24,55 15,69 C 13,72 16,74 21,70 C 30,64 41,62 52,64 C 55,65 57,60 56,55 Z"
          fill="url(#purple-wing-grad)"
          opacity="0.85"
        />

        {/* Feather 4 */}
        <path
          d="M 57,70 C 41,67 24,73 17,89 C 15,93 18,94 22,90 C 31,82 42,80 52,81 C 55,81 57,76 57,70 Z"
          fill="url(#purple-wing-grad)"
          opacity="0.85"
        />

        {/* Feather 5 (Bottom-most tail of purple) */}
        <path
          d="M 57,84 C 43,82 28,91 22,103 C 20,107 24,107 27,103 C 34,95 44,92 53,92 C 56,92 58,88 57,84 Z"
          fill="url(#purple-wing-grad)"
          opacity="0.8"
        />

        {/* RIGHT PART: Sleek smooth gradient stroke curving into sharp end forming the right hand side of 'M' */}
        <path
          d="M 58,51 C 60,35 68,21 84,23 C 94,24 102,32 104,46 C 106,60 102,78 96,93 C 94,97 91,101 88,104 C 85,107 81,102 83,97 C 86,91 90,83 93,73 C 97,60 97,47 93,40 C 90,34 83,34 78,39 C 71,46 66,58 63,73 C 61,83 58,93 56,102 C 55,106 51,106 51,100 C 53,88 56,71 58,51 Z"
          fill="url(#blue-wing-grad)"
        />
      </g>
    </svg>
  );
}
