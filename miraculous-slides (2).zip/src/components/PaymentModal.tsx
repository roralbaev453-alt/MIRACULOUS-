import React, { useState } from "react";
import { X, CreditCard, Check, Sparkles, Award } from "lucide-react";
import { Language, TRANSLATIONS } from "../translations";
import { Logo } from "./Logo";

interface PaymentModalProps {
  isOpen: boolean;
  onClose: () => void;
  onPaymentSuccess: () => void;
  lang: Language;
}

type Mode = "click" | "payme" | "visa";

export default function PaymentModal({ isOpen, onClose, onPaymentSuccess, lang }: PaymentModalProps) {
  const [selectedMode, setSelectedMode] = useState<Mode>("click");
  const [cardNumber, setCardNumber] = useState("");
  const [cardHolder, setCardHolder] = useState("");
  const [isProcessing, setIsProcessing] = useState(false);
  const [isPaid, setIsPaid] = useState(false);

  const t = TRANSLATIONS[lang];

  if (!isOpen) return null;

  const handlePay = (e: React.FormEvent) => {
    e.preventDefault();
    setIsProcessing(true);

    setTimeout(() => {
      setIsProcessing(false);
      setIsPaid(true);
      setTimeout(() => {
        onPaymentSuccess();
        onClose();
        setIsPaid(false);
        setCardNumber("");
        setCardHolder("");
      }, 1500);
    }, 1800);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/90 backdrop-blur-md">
      
      {/* Container aligned with Image 6 details (Teal/Indigo Cosmic Cyber Deck) */}
      <div 
        className="w-full max-w-lg rounded-3xl p-6 md:p-8 border border-teal-500/30 overflow-hidden relative shadow-2xl"
        style={{
          background: "linear-gradient(135deg, #050e12, #02080a, #07070b)",
          boxShadow: "0 30px 60px -15px rgba(20, 184, 166, 0.4), 0 0 50px rgba(99, 102, 241, 0.2)"
        }}
      >
        {/* Top glossy banner highlight */}
        <div className="absolute top-0 left-0 right-0 h-1.5 bg-gradient-to-r from-teal-400 via-sky-500 to-indigo-600" />
        
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-5 right-5 p-1 rounded-full bg-zinc-950/80 hover:bg-zinc-900 border border-teal-500/20 text-zinc-400 hover:text-white transition-all focus:outline-none cursor-pointer"
        >
          <X className="h-4 w-4" />
        </button>

        {/* Header containing Name and Slogan matching Image 6 layout */}
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center space-x-2">
            <Logo size={24} />
            <span className="text-[10px] font-mono font-black text-white/60 tracking-widest uppercase">
              {t.logoTitle}
            </span>
          </div>
          
          <div className="py-0.5 px-3 rounded-full bg-teal-950/80 border border-teal-500/30 text-[10px] font-bold text-teal-300 tracking-wider shadow-[0_0_15px_rgba(20,184,166,0.2)]">
            {t.unlockTitle}
          </div>
        </div>

        {/* Section Title matching Image 6 precisely */}
        <div className="text-center mb-8">
          <h2 className="text-2xl font-black text-white tracking-wide uppercase font-sans drop-shadow-[0_0_10px_rgba(255,255,255,0.15)]">
            {t.unlockTitle}
          </h2>
          <p className="text-xs text-teal-400/80 font-mono mt-1 uppercase tracking-widest font-semibold">
            {t.unlockDesc}
          </p>
        </div>

        {isPaid ? (
          <div className="py-12 text-center space-y-4">
            <div className="mx-auto h-16 w-16 rounded-full bg-teal-950/30 border border-teal-400 flex items-center justify-center animate-bounce shadow-[0_0_20px_rgba(20,184,166,0.3)]">
              <Check className="h-8 w-8 text-teal-300" />
            </div>
            <h3 className="text-lg font-bold text-white">{t.purchasedCongrats}</h3>
            <p className="text-xs text-teal-200/80 max-w-sm mx-auto">
              {t.purchasedDesc}
            </p>
          </div>
        ) : (
          <div className="space-y-6">
            
            {/* Payment Method selectors (replicating the CLICK, PAYME, VISA pill graphics in Image 6) */}
            <div className="grid grid-cols-3 gap-3">
              {[
                { 
                  id: "click", 
                  label: "CLICK", 
                  activeStyles: "border-blue-500 bg-blue-950/40 text-blue-300 shadow-[0_0_15px_rgba(59,130,246,0.35)]",
                  pillsColor: "bg-blue-500" 
                },
                { 
                  id: "payme", 
                  label: "PAYME", 
                  activeStyles: "border-teal-400 bg-teal-950/40 text-teal-300 shadow-[0_0_15px_rgba(20,184,166,0.35)]",
                  pillsColor: "bg-teal-500" 
                },
                { 
                  id: "visa", 
                  label: "VISA", 
                  activeStyles: "border-indigo-500 bg-indigo-950/40 text-indigo-300 shadow-[0_0_15px_rgba(99,102,241,0.35)]",
                  pillsColor: "bg-indigo-500" 
                }
              ].map((method) => {
                const isSelected = selectedMode === method.id;
                return (
                  <button
                    key={method.id}
                    onClick={() => setSelectedMode(method.id as Mode)}
                    className={`relative p-4 rounded-2xl border transition-all text-xs font-black tracking-wider focus:outline-none flex flex-col items-center justify-center space-y-2 cursor-pointer ${
                      isSelected 
                        ? method.activeStyles 
                        : "border-zinc-800/80 bg-zinc-950/50 text-slate-500 hover:text-slate-300 hover:bg-[#0c181c]"
                    }`}
                    id={`pay-tab-${method.id}`}
                  >
                    {/* Tick overlay if selected */}
                    {isSelected && (
                      <span className={`absolute -top-1.5 -right-1.5 h-5 w-5 rounded-full border border-black flex items-center justify-center text-[10px] text-white font-bold shadow ${method.pillsColor}`}>
                        ✓
                      </span>
                    )}

                    <span className="text-[10px] font-mono tracking-widest block uppercase font-bold text-white">
                      {method.label}
                    </span>
                  </button>
                );
              })}
            </div>

            {/* Standard payment input state form */}
            <form onSubmit={handlePay} className="space-y-4">
              <div>
                <label className="block text-xs font-semibold text-slate-400 mb-1.5" htmlFor="pay-card-num">
                  {t.cardNumLabel}
                </label>
                <div className="relative font-mono">
                  <span className="absolute left-3.5 top-1/2 -translate-y-1/2 text-teal-500">
                    <CreditCard className="h-4 w-4" />
                  </span>
                  <input
                    type="text"
                    id="pay-card-num"
                    required
                    maxLength={19}
                    className="w-full bg-[#03090b] text-sm border border-teal-500/20 focus:border-teal-400 rounded-xl pl-10 pr-4 py-2.5 text-white placeholder-slate-650 focus:outline-none focus:ring-1 focus:ring-teal-450/20"
                    placeholder="8600 xxxx xxxx xxxx"
                    value={cardNumber}
                    onChange={(e) => {
                      // Basic card formatter layout helper
                      const val = e.target.value.replace(/\D/g, "");
                      const matches = val.match(/\d{4,16}/g);
                      const match = (matches && matches[0]) || "";
                      const parts = [];
                      for (let i = 0, len = match.length; i < len; i += 4) {
                        parts.push(match.substring(i, i + 4));
                      }
                      if (parts.length > 0) {
                        setCardNumber(parts.join(" "));
                      } else {
                        setCardNumber(val);
                      }
                    }}
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-400 mb-1.5" htmlFor="pay-holder">
                  {t.cardHolderLabel}
                </label>
                <input
                  type="text"
                  id="pay-holder"
                  required
                  className="w-full bg-[#03090b] text-sm border border-teal-500/20 focus:border-teal-400 rounded-xl px-4 py-2.5 text-white uppercase placeholder-slate-600 focus:outline-none focus:ring-1 focus:ring-teal-450/20 font-mono"
                  placeholder="FATXULLA OLIMJONOV"
                  value={cardHolder}
                  onChange={(e) => setCardHolder(e.target.value)}
                />
              </div>

              {/* simulated payment triggers (Partnership handshake in Image 6 is printed as premium protection indicators) */}
              <div className="p-4 rounded-2xl bg-teal-950/20 border border-teal-500/20 flex items-start space-x-3 mt-2">
                <div className="p-1 rounded bg-teal-950/70 text-teal-300 shadow mt-0.5">
                  <Award className="h-4 w-4" />
                </div>
                <div className="space-y-1">
                  <p className="text-[11px] font-bold text-teal-300">{t.secureContract}</p>
                  <p className="text-[9px] text-teal-400/70 leading-relaxed">
                    {t.secureDesc}
                  </p>
                </div>
              </div>

              {/* Payment Submit Button */}
              <div className="pt-4">
                <button
                  type="submit"
                  disabled={isProcessing}
                  className="w-full py-3.5 px-4 bg-gradient-to-r from-teal-500 via-sky-500 to-indigo-600 hover:from-teal-400 hover:to-indigo-500 rounded-xl text-xs font-extrabold text-white shadow-xl shadow-teal-950/40 hover:opacity-95 focus:outline-none transition-all flex items-center justify-center space-x-2 cursor-pointer"
                  id="process-payment-btn"
                >
                  {isProcessing ? (
                    <div className="h-4 w-4 rounded-full border-2 border-white/30 border-t-white animate-spin" />
                  ) : (
                    <>
                      <Sparkles className="h-4 w-4 text-yellow-350 animate-pulse animate-bounce" />
                      <span>{t.oneTimeUnlock}</span>
                    </>
                  )}
                </button>
              </div>

            </form>
          </div>
        )}

      </div>
    </div>
  );
}
