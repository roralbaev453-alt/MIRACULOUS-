import React, { useState } from "react";
import { Mail, Lock, X, Eye, EyeOff, Sparkles, AlertCircle } from "lucide-react";
import { Language, TRANSLATIONS } from "../translations";
import { Logo } from "./Logo";

interface LoginModalProps {
  isOpen: boolean;
  onClose: () => void;
  onLoginSuccess: (email: string, name: string) => void;
  lang: Language;
}

export default function LoginModal({ isOpen, onClose, onLoginSuccess, lang }: LoginModalProps) {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [isSignUp, setIsSignUp] = useState(false);
  const [name, setName] = useState("");
  const [error, setError] = useState("");
  const [isLoading, setIsLoading] = useState(false);

  const t = TRANSLATIONS[lang];

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError("");

    if (!email || !password) {
      setError(lang === "uz" ? "Iltimos, barcha mayonlarni to'ldiring." : lang === "ru" ? "Заполните все поля." : "Please fill in all fields.");
      return;
    }

    if (isSignUp && !name) {
      setError(lang === "uz" ? "Iltimos, ismingizni kiriting." : lang === "ru" ? "Введите имя." : "Please write down your name.");
      return;
    }

    setIsLoading(true);

    // Simulate login network response safely
    setTimeout(() => {
      setIsLoading(false);
      const displayName = name || email.split("@")[0];
      onLoginSuccess(email, displayName);
      onClose();
    }, 1200);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md">
      
      {/* Outer Wavy Metallic Background Panel mirroring Image 5 */}
      <div 
        className="relative w-full max-w-md rounded-3xl p-8 border border-teal-500/30 bg-[#0d0f12] shadow-2xl overflow-hidden"
        style={{
          boxShadow: "0 30px 60px -15px rgba(20, 184, 166, 0.3), 0 0 40px rgba(99, 102, 241, 0.1)"
        }}
      >
        <div className="absolute top-0 left-0 right-0 h-1 bg-gradient-to-r from-teal-400 to-indigo-500" />
        
        {/* Absolute metallic wave decorations (from Image 5 rendering) */}
        <div className="absolute top-0 right-0 left-0 h-40 bg-gradient-to-b from-teal-500/10 via-slate-900/40 to-transparent blur-xl pointer-events-none" />
        
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-5 right-5 p-1 rounded-full bg-zinc-950/80 border border-teal-500/20 text-zinc-400 hover:text-white hover:bg-zinc-800 transition-all cursor-pointer"
        >
          <X className="h-4 w-4" />
        </button>

        {/* Logo / Brand Header */}
        <div className="text-center mb-6 text-slate-100">
          <div className="mx-auto flex justify-center mb-3">
            <Logo size={54} className="hover:scale-105 transition-transform" />
          </div>
          
          <h2 className="text-xl font-extrabold text-white uppercase tracking-tight">
            {t.loginRequiredTitle}
          </h2>
          <p className="text-xs text-teal-400/80 font-mono mt-1 leading-relaxed">
            {t.loginRequiredDesc}
          </p>
        </div>

        {/* Validation Errors */}
        {error && (
          <div className="mb-5 p-3 rounded-xl bg-red-950/30 border border-red-805/50 flex items-center space-x-2 text-red-300 text-xs">
            <AlertCircle className="h-4 w-4 shrink-0 text-red-400" />
            <span>{error}</span>
          </div>
        )}

        {/* Form Container */}
        <form onSubmit={handleSubmit} className="space-y-4">
          {isSignUp && (
            <div>
              <label className="block text-xs font-semibold text-slate-400 mb-1.5" htmlFor="login-name">
                {lang === "uz" ? "Ismingiz" : lang === "ru" ? "Ваше Имя" : "Your Name"}
              </label>
              <div className="relative">
                <input
                  type="text"
                  id="login-name"
                  className="w-full bg-[#04080a] text-sm border border-zinc-800 focus:border-teal-450 rounded-xl px-4 py-2.5 text-white placeholder-zinc-700 focus:outline-none"
                  placeholder={lang === "uz" ? "Ismingizni kiriting" : "Kamron Aliyev"}
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                />
              </div>
            </div>
          )}

          <div>
            <label className="block text-xs font-semibold text-slate-400 mb-1.5" htmlFor="login-email">
              {lang === "uz" ? "Elektron pochta" : "Email / Gmail"}
            </label>
            <div className="relative font-mono">
              <span className="absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-500">
                <Mail className="h-4 w-4" />
              </span>
              <input
                type="email"
                id="login-email"
                className="w-full bg-[#04080a] text-sm border border-zinc-800 focus:border-teal-450 rounded-xl pl-10 pr-4 py-2.5 text-white placeholder-zinc-750 focus:outline-none"
                placeholder="example@gmail.com"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                required
              />
            </div>
          </div>

          <div>
            <div className="flex items-center justify-between mb-1.5">
              <label className="text-xs font-semibold text-slate-400" htmlFor="login-password">
                {lang === "uz" ? "Parol" : lang === "ru" ? "Пароль" : "Password"}
              </label>
            </div>
            
            <div className="relative font-mono">
              <span className="absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-500">
                <Lock className="h-4 w-4" />
              </span>
              <input
                type={showPassword ? "text" : "password"}
                id="login-password"
                className="w-full bg-[#04080a] text-sm border border-zinc-800 focus:border-teal-450 rounded-xl pl-10 pr-10 py-2.5 text-white placeholder-zinc-750 focus:outline-none"
                placeholder="••••••••"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                required
              />
              <button
                type="button"
                onClick={() => setShowPassword(!showPassword)}
                className="absolute right-3.5 top-1/2 -translate-y-1/2 text-zinc-500 hover:text-slate-300 focus:outline-none cursor-pointer"
              >
                {showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
              </button>
            </div>
          </div>

          {/* Submit Trigger matched to Image 5 glowing button item */}
          <div className="pt-4">
            <button
              type="submit"
              disabled={isLoading}
              className="w-full py-3 px-4 bg-gradient-to-r from-teal-500 to-indigo-650 rounded-xl text-xs font-bold text-white shadow-lg shadow-teal-950/40 hover:opacity-90 active:scale-98 transition-all flex items-center justify-center space-x-2 cursor-pointer"
              id="submit-login-btn"
            >
              {isLoading ? (
                <div className="h-4 w-4 rounded-full border-2 border-white/30 border-t-white animate-spin" />
              ) : (
                <>
                  <Sparkles className="h-3.5 w-3.5 text-yellow-300 animate-pulse" />
                  <span>{t.loginBtnLabel}</span>
                </>
              )}
            </button>
          </div>
        </form>

        {/* Alternative sign up footer matched to Image 5 */}
        <div className="mt-6 text-center border-t border-zinc-900/60 pt-4 text-[11px] text-slate-500">
          <span>{isSignUp ? (lang === "uz" ? "Hisobingiz bormi? " : "Already registered? ") : (lang === "uz" ? "Yangi foydalanuvchimisiz? " : "Are You A New Member? ")}</span>
          <button
            type="button"
            onClick={() => setIsSignUp(!isSignUp)}
            className="text-teal-400 font-bold hover:underline focus:outline-none uppercase tracking-wider text-[10px] cursor-pointer ml-1"
            id="toggle-signup-btn"
          >
            {isSignUp ? t.login : (lang === "uz" ? "Ro'yxatdan o'tish" : "Sign UP")}
          </button>
        </div>

      </div>
    </div>
  );
}
