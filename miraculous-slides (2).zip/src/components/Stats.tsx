import React from "react";
import { STATS_ITEMS } from "../data";
import { Language, TRANSLATIONS } from "../translations";
import { Trophy, Users, BarChart3, Presentation, Star, Bookmark, Settings } from "lucide-react";

// Helper to assign icons to metrics dynamically
const getIcon = (val: string) => {
  if (val.includes("150")) return <Users className="h-5 w-5 text-teal-400" />;
  if (val.includes("250")) return <Trophy className="h-5 w-5 text-teal-400" />;
  if (val.includes("100")) return <Settings className="h-5 w-5 text-teal-400" />;
  if (val.includes("82")) return <Presentation className="h-5 w-5 text-teal-400" />;
  if (val.includes("500")) return <Star className="h-5 w-5 text-yellow-350 nav-glow" />;
  if (val.includes("350")) return <Bookmark className="h-5 w-5 text-teal-400" />;
  return <BarChart3 className="h-5 w-5 text-teal-400" />;
};

interface StatsProps {
  lang: Language;
}

export default function Stats({ lang }: StatsProps) {
  const t = TRANSLATIONS[lang];

  return (
    <section className="relative py-16 px-4 bg-[#09090b] border-t border-zinc-900">
      
      {/* Decorative vertical lines on sides to evoke architectural drafts style */}
      <div className="absolute inset-y-0 left-8 w-[1px] bg-zinc-900/40 hidden lg:block" />
      <div className="absolute inset-y-0 right-8 w-[1px] bg-zinc-900/40 hidden lg:block" />

      <div className="mx-auto max-w-7xl relative z-10">
        
        {/* Section title as highlighted badge */}
        <div className="text-center mb-10">
          <span className="text-teal-500 font-mono text-[11px] uppercase tracking-widest block mb-2 font-black">
            {t.statsTitle}
          </span>
          <h3 className="text-xl sm:text-2xl font-black text-transparent bg-clip-text bg-gradient-to-r from-zinc-100 via-teal-100 to-zinc-400 uppercase tracking-wider font-sans">
            "{t.statsDesc}"
          </h3>
          <div className="h-0.5 w-12 bg-teal-500 mx-auto mt-4 rounded" />
        </div>

        {/* Infinite Scrolling Marquee for Stats items */}
        <div className="w-full overflow-hidden mask-grad relative py-6">
          <div className="animate-marquee flex gap-4 pr-4">
            {[...STATS_ITEMS, ...STATS_ITEMS].map((stat, idx) => {
              // Smart translation mapping
              let label = stat.label;
              let desc = stat.desc;

              if (lang === "ru") {
                if (stat.value.includes("150")) { label = "Анализ интервью"; desc = "Изучены потребности клиентов"; }
                else if (stat.value.includes("250")) { label = "Решение проблем"; desc = "Проекты безопасности повышенной сложности"; }
                else if (stat.value.includes("100")) { label = "Параметров учтено"; desc = "Выверенные структуры слайдов"; }
                else if (stat.value.includes("82")) { label = "Варианты презентаций"; desc = "Различные стили плавной анимации"; }
                else if (stat.value.includes("500")) { label = "Положительных отзывов"; desc = "От пользователей по всему миру"; }
                else if (stat.value.includes("8")) { label = "Созданные разделы"; desc = "Основные темы уроков"; }
                else if (stat.value.includes("350")) { label = "Анимированных слайдов"; desc = "Готовы к использованию за секунды"; }
              } else if (lang === "en") {
                if (stat.value.includes("150")) { label = "Interview Analysis"; desc = "Client needs thoroughly analyzed"; }
                else if (stat.value.includes("250")) { label = "Secured Solutions"; desc = "Tailored security configurations"; }
                else if (stat.value.includes("100")) { label = "Parameters Checked"; desc = "Strict slide layouts and rules"; }
                else if (stat.value.includes("82")) { label = "Pre-animated Modes"; desc = "Dynamic transitions and speeds"; }
                else if (stat.value.includes("500")) { label = "Positive Feedback"; desc = "From clients across the globe"; }
                else if (stat.value.includes("8")) { label = "Created Categories"; desc = "Primary educational subjects"; }
                else if (stat.value.includes("350")) { label = "Animated Templates"; desc = "Ready to customize and download"; }
              }

              return (
                <div
                  key={idx}
                  className="relative overflow-hidden rounded-2xl p-5 border transition-all duration-300 group hover:-translate-y-1 bg-[#121214] border-zinc-800/80 hover:border-slate-700 shadow-md w-64 sm:w-72 shrink-0"
                  id={`stat-card-${idx}`}
                >
                  {/* Internal abstract light lines */}
                  <div className="absolute top-0 right-0 h-10 w-10 bg-teal-500/5 rounded-full blur-lg opacity-0 group-hover:opacity-100 transition-opacity" />

                  {/* Icon Container */}
                  <div className="mb-4 flex items-center justify-between">
                    <div className="p-2 rounded-xl bg-black/40 border border-zinc-800/60 group-hover:border-teal-700/40">
                      {getIcon(stat.value)}
                    </div>
                    <span className="text-[10px] text-zinc-500 font-mono font-bold">
                      No. 0{(idx % STATS_ITEMS.length) + 1}
                    </span>
                  </div>

                  {/* Giant numbers */}
                  <div className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight font-sans">
                    {stat.value}
                  </div>

                  {/* Label */}
                  <div className="text-xs font-bold text-slate-300 mt-2 truncate font-sans">
                    {label}
                  </div>

                  {/* Sub description */}
                  <div className="text-[10px] text-slate-500 mt-1 line-clamp-2">
                    {desc}
                  </div>

                  {/* Under-glow line on hover */}
                  <div className="absolute bottom-0 left-0 right-0 h-0.5 bg-gradient-to-r from-teal-500 via-sky-400 to-indigo-500 transform scale-x-0 group-hover:scale-x-100 transition-transform duration-300" />
                </div>
              );
            })}
          </div>
        </div>

        {/* Extra Action Micro Banner as in bottom image bar */}
        <div className="mt-8 flex flex-wrap items-center justify-center gap-3">
          <span className="text-[11px] text-slate-500 font-mono">Status:</span>
          <span className="py-1 px-3 rounded-full text-[10px] text-slate-400 bg-zinc-90 w-full border border-zinc-800/80">
            Onerch
          </span>
          <span className="py-1 px-3 rounded-full text-[10px] text-slate-400 bg-zinc-90 w-full border border-zinc-800/80">
            Get check look in
          </span>
          <span className="py-1 px-3 rounded-full text-[10px] text-teal-400 bg-teal-950/20 border border-teal-900/30 font-bold">
            Brock a heading
          </span>
        </div>

      </div>
    </section>
  );
}
