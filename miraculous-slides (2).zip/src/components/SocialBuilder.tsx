import React, { useState } from "react";
import { Share2, Sparkles, Send, Flame, MessageCircle, Heart, Bookmark, Eye } from "lucide-react";
import { motion } from "motion/react";

export default function SocialBuilder() {
  const [postTitle, setPostTitle] = useState("Siz kutgan mo'jizalar!");
  const [postSlogan, setPostSlogan] = useState("Maxsus tayyorlangan animatsion slaydlar...");
  const [platform, setPlatform] = useState<"instagram" | "telegram">("instagram");
  const [metricLikes, setMetricLikes] = useState(1420);
  const [metricComments, setMetricComments] = useState(89);

  return (
    <section className="relative py-16 px-4 bg-[#09090b] min-h-[80vh] flex flex-col justify-center border-t border-zinc-900">
      
      {/* Visual background decorations resembling Bento layout */}
      <div className="absolute top-10 right-20 h-40 w-40 rounded-full bg-indigo-500/5 blur-2xl" />
      <div className="absolute bottom-10 left-10 h-60 w-60 rounded-full bg-indigo-600/5 blur-3xl" />

      <div className="mx-auto max-w-6xl w-full relative z-10">
        
        {/* Title Group of SMM builder */}
        <div className="text-center mb-12 space-y-4">
          <span className="text-xs font-bold text-indigo-400 font-mono uppercase tracking-[0.25em]">
            Eye-Catching templates
          </span>
          <h2 className="text-4xl sm:text-5xl font-extrabold text-white leading-tight">
            Bizning Ijtimoiy
            <span className="block italic text-transparent bg-clip-text bg-gradient-to-r from-indigo-400 to-sky-400">
              TARMOQLAR
            </span>
          </h2>
          
          {/* Subheader action tags as shown in Image 4 */}
          <div className="inline-flex items-center space-x-2 py-1 px-4 rounded-full border border-zinc-800 bg-zinc-900/60 font-mono text-[10px] sm:text-xs text-slate-400">
            <span>&lsaquo; ELEVATE</span>
            <span className="text-indigo-500">&bull;</span>
            <span>CAPTIVATE</span>
            <span className="text-indigo-500">&bull;</span>
            <span>CONVERT &rsaquo;</span>
          </div>
        </div>

        {/* Master layout panel */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
          
          {/* Left Panel: Form Controls to create their customized poster */}
          <div className="lg:col-span-5 bg-[#121214] p-6 rounded-3xl border border-zinc-800/80 shadow-xl space-y-6">
            <div className="flex items-center justify-between border-b border-zinc-900/60 pb-4">
              <h3 className="text-base font-bold text-white flex items-center space-x-2 font-sans">
                <Sparkles className="h-4.5 w-4.5 text-indigo-400" />
                <span>Format Sozlamalari</span>
              </h3>
              <div className="flex space-x-1">
                <button
                  onClick={() => setPlatform("instagram")}
                  className={`text-[10px] font-bold px-3 py-1 rounded-full transition-all cursor-pointer ${
                    platform === "instagram" ? "bg-indigo-600 text-white" : "bg-zinc-900 text-slate-400 hover:text-white"
                  }`}
                >
                  Instagram
                </button>
                <button
                  onClick={() => setPlatform("telegram")}
                  className={`text-[10px] font-bold px-3 py-1 rounded-full transition-all cursor-pointer ${
                    platform === "telegram" ? "bg-indigo-650 text-white" : "bg-zinc-900 text-slate-400 hover:text-white"
                  }`}
                >
                  Telegram
                </button>
              </div>
            </div>

            {/* Inputs */}
            <div className="space-y-4">
              <div>
                <label className="block text-xs font-semibold text-slate-400 mb-1.5" htmlFor="post-title-input">
                  Post Sarlavhasi
                </label>
                <input
                  type="text"
                  id="post-title-input"
                  className="w-full bg-zinc-950/80 text-sm border border-zinc-805 focus:border-indigo-500 rounded-xl px-4 py-2.5 text-white placeholder-zinc-600 focus:outline-none focus:ring-1 focus:ring-indigo-550/25"
                  value={postTitle}
                  onChange={(e) => setPostTitle(e.target.value)}
                  placeholder="Masalan: Sayohatingizni rejalashtiring"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-400 mb-1.5" htmlFor="post-slogan-input">
                  Post Tavsifi / Slogani
                </label>
                <textarea
                  id="post-slogan-input"
                  rows={3}
                  className="w-full bg-zinc-950/80 text-sm border border-zinc-805 focus:border-indigo-500 rounded-xl px-4 py-2.5 text-white placeholder-zinc-650 focus:outline-none focus:ring-1 focus:ring-indigo-550/25"
                  value={postSlogan}
                  onChange={(e) => setPostSlogan(e.target.value)}
                  placeholder="Muxlislaringizni jalb qiladigan chiroyli ibora..."
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-semibold text-slate-400 mb-1.5" htmlFor="post-likes-input">
                    Simulyatsiya Layk
                  </label>
                  <input
                    type="number"
                    id="post-likes-input"
                    className="w-full bg-zinc-950/80 text-sm border border-zinc-805 focus:border-indigo-500 rounded-xl px-4 py-2.5 text-white focus:outline-none"
                    value={metricLikes}
                    onChange={(e) => setMetricLikes(Math.max(0, parseInt(e.target.value) || 0))}
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-400 mb-1.5" htmlFor="post-comments-input">
                    Izohlar soni
                  </label>
                  <input
                    type="number"
                    id="post-comments-input"
                    className="w-full bg-zinc-950/80 text-sm border border-zinc-805 focus:border-indigo-500 rounded-xl px-4 py-2.5 text-white focus:outline-none"
                    value={metricComments}
                    onChange={(e) => setMetricComments(Math.max(0, parseInt(e.target.value) || 0))}
                  />
                </div>
              </div>
            </div>

            <div className="pt-2 text-center">
              <span className="text-[10px] text-slate-500 italic block">
                SMM postlar andozalarini onlayn generatsiya qilish imkoniyati
              </span>
            </div>
          </div>

          {/* Right Panel: Isometric SMM Mockup (Image 4 exact visual presentation match) */}
          <div className="lg:col-span-7 flex justify-center">
            
            {/* Isometric Rotation Wrapper to match the artistic angle of Image 4 */}
            <div 
              className="relative w-full max-w-[380px] h-[440px] flex items-center justify-center"
              style={{ perspective: "1200px" }}
            >
              
              {/* Dynamic Mockup Card (Glassmorphic SMM Template Frame) */}
              <div 
                className="w-76 h-96 rounded-3xl border border-white/10 p-5 flex flex-col justify-between relative shadow-2xl transition-all duration-500"
                style={{
                  transform: "rotateY(-15deg) rotateX(15deg) rotateZ(5deg)",
                  background: platform === "instagram" 
                    ? "radial-gradient(circle at top left, rgba(79, 70, 229, 0.45) 0%, rgba(15, 10, 30, 0.9) 80%)"
                    : "radial-gradient(circle at top left, rgba(30, 58, 138, 0.45) 0%, rgba(5, 10, 20, 0.9) 80%)",
                  boxShadow: platform === "instagram"
                    ? "0 30px 60px rgba(99, 102, 241, 0.15), inset 0 2px 10px rgba(255, 255, 255, 0.15)"
                    : "0 30px 60px rgba(14, 165, 233, 0.15), inset 0 2px 10px rgba(255, 255, 255, 0.15)",
                }}
              >
                
                {/* SMM Platform Header */}
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-2">
                    <div className={`h-8 w-8 rounded-full flex items-center justify-center shadow ${
                      platform === "instagram" ? "bg-gradient-to-tr from-yellow-500 via-indigo-500 to-indigo-650" : "bg-indigo-600"
                    }`}>
                      {platform === "instagram" ? (
                        <div className="h-4 w-4 rounded bg-transparent border-2 border-white flex items-center justify-center">
                          <div className="h-1.5 w-1.5 rounded-full border border-white" />
                        </div>
                      ) : (
                        <Send className="h-3 w-3 text-white transform -translate-x-0.5 translate-y-0.5 skew-y-6" />
                      )}
                    </div>
                    <div>
                      <span className="text-xs font-bold text-white block">Miraculous Slides</span>
                      <span className="text-[8px] text-slate-500 block font-mono">@miraculous_slides</span>
                    </div>
                  </div>
                  
                  {/* Small Action tag */}
                  <div className="py-0.5 px-2.5 rounded-full border border-zinc-800 bg-black/50 text-[8px] text-indigo-400 font-mono font-bold">
                    ONLINE
                  </div>
                </div>

                {/* Main Creative Center */}
                <div className="my-4 grow flex flex-col justify-center text-center space-y-3 px-2 relative">
                  
                  {/* Decorative glowing backplane */}
                  <div className="absolute inset-x-2 inset-y-6 bg-gradient-to-tr from-indigo-500/10 via-sky-500/10 to-transparent blur-md pointer-events-none" />

                  <span className="text-[9px] text-indigo-400 uppercase tracking-widest font-mono font-bold inline-block">
                    TEMPLATE SHOWCASE
                  </span>

                  <h4 className="text-lg font-black text-white leading-tight tracking-tight drop-shadow-md capitalize">
                    {postTitle}
                  </h4>

                  <p className="text-[11px] text-slate-400 leading-relaxed font-sans line-clamp-3">
                    {postSlogan}
                  </p>
                </div>

                {/* Interactive metrics footer */}
                <div className="border-t border-white/5 pt-4 flex items-center justify-between text-slate-400 text-[10px]">
                  <div className="flex items-center space-x-4">
                    <span className="flex items-center space-x-1 hover:text-indigo-400 cursor-pointer">
                      <Heart className="h-3.5 w-3.5 text-indigo-500 fill-current" />
                      <span className="font-mono font-bold">{metricLikes}</span>
                    </span>
                    <span className="flex items-center space-x-1 hover:text-indigo-400 cursor-pointer">
                      <MessageCircle className="h-3.5 w-3.5" />
                      <span className="font-mono font-bold">{metricComments}</span>
                    </span>
                  </div>

                  <Bookmark className="h-3.5 w-3.5 hover:text-indigo-450 cursor-pointer" />
                </div>

                {/* Background 3D Isometric Elements Floating Behind */}
                <div className="absolute -bottom-10 -right-8 h-20 w-20 rounded bg-gradient-to-tr from-indigo-600/15 to-transparent border border-white/5 rotate-45 transform translate-z-[-50px] pointer-events-none" />
                <div className="absolute -top-6 -left-10 h-16 w-16 rounded-full bg-gradient-to-tr from-indigo-500/10 to-transparent blur-xs transform translate-z-[-80px] pointer-events-none" />

              </div>

              {/* Extra visual shadows */}
              <div 
                className="absolute w-74 h-90 rounded-3xl bg-zinc-950/80 -z-10 border border-zinc-900 pointer-events-none"
                style={{
                  transform: "rotateY(-15deg) rotateX(15deg) rotateZ(5deg) translateZ(-40px) translateY(15px)",
                  boxShadow: "0 40px 80px rgba(0,0,0,0.8)"
                }}
              />

              {/* Holographic beams reflecting from the bottom */}
              <div className="absolute bottom-4 left-1/2 -translate-x-1/2 h-1 w-24 bg-indigo-500/50 blur-xs rounded-full transform -skew-x-12 ring-4 ring-indigo-600/20 animate-pulse" />

            </div>

          </div>

        </div>

        {/* Extra footer line from Design theme */}
        <div className="mt-16 text-center text-[10px] sm:text-xs text-slate-500 font-mono tracking-wider">
          CUSTOM DESIGNS &bull; ABSTRCNC CNNNRT &bull; BBAK GRFECT
        </div>

      </div>
    </section>
  );
}
