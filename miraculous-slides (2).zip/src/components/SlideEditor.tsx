import React, { useState, useEffect } from "react";
import { Slide, CategoryId, User as UserType } from "../types";
import { CATEGORIES_LIST } from "../data";
import { Language, TRANSLATIONS } from "../translations";
import { 
  Sparkles, 
  Plus, 
  Trash2, 
  Play, 
  CheckCircle, 
  ChevronLeft, 
  ChevronRight, 
  Maximize2, 
  X, 
  Layout, 
  Palette, 
  FileText,
  HelpCircle,
  Cpu,
  Crown,
  Copy,
  Check,
  Lock,
  Layers,
  Download
} from "lucide-react";
import { generateCustomSlidesForCategory } from "../slidesData";
import { motion, AnimatePresence } from "motion/react";

interface SlideEditorProps {
  category: CategoryId;
  user: UserType | null;
  onUpgradePrompt: () => void;
  onOpenLogin: () => void;
  lang: Language;
  hasUnlocked: boolean;
}

export default function SlideEditor({ 
  category, 
  user, 
  onUpgradePrompt, 
  onOpenLogin, 
  lang, 
  hasUnlocked 
}: SlideEditorProps) {
  const t = TRANSLATIONS[lang];
  // Grab active category config detail
  const categoryConfig = CATEGORIES_LIST.find((c) => c.id === category) || CATEGORIES_LIST[0];


  const [selectedPageCount, setSelectedPageCount] = useState<number>(5);

  const [slides, setSlides] = useState<Slide[]>(() => {
    return generateCustomSlidesForCategory(lang, category, 5);
  });

  const [activeSlideIndex, setActiveSlideIndex] = useState(0);
  const [isPresenting, setIsPresenting] = useState(false);

  // Update slides if categories shift
  useEffect(() => {
    const defaultCount = 5;
    setSelectedPageCount(defaultCount);
    setSlides(generateCustomSlidesForCategory(lang, category, defaultCount));
    setActiveSlideIndex(0);
  }, [category, lang]);

  const activeSlide = slides[activeSlideIndex] || slides[0] || null;

  const updateActiveSlide = (updatedFields: Partial<Slide>) => {
    if (!activeSlide) return;
    setSlides((prev) => {
      const copy = [...prev];
      copy[activeSlideIndex] = {
        ...copy[activeSlideIndex],
        ...updatedFields,
      };
      return copy;
    });
  };

  const addSlide = () => {
    const newSlide: Slide = {
      id: `slide-${Date.now()}`,
      title: "Yangi Slayd nomi",
      subtitle: "Kichikroq sarlavha yoki rukn",
      content: "Ushbu slayd uchun o'zingiz xohlagan batafsil ma'lumotlarni kiriting. Siz sun'iy intellektdan ham foydalanishingiz mumkin.",
      layout: "simple",
      accentColor: "indigo"
    };
    setSlides((prev) => [...prev, newSlide]);
    setActiveSlideIndex(slides.length);
  };

  const removeSlide = (idx: number) => {
    if (slides.length <= 1) {
      alert("Kamida bitta slayd bo'lishi shart.");
      return;
    }
    setSlides((prev) => prev.filter((_, i) => i !== idx));
    setActiveSlideIndex((prev) => {
      if (prev >= slides.length - 1) return Math.max(0, slides.length - 2);
      return prev;
    });
  };

  const [copiedStatus, setCopiedStatus] = useState<"idle" | "slide" | "all">("idle");

  const copyActiveSlide = () => {
    if (!activeSlide) return;
    const text = `### Slayd ${activeSlideIndex + 1}: ${activeSlide.title}\n*Subtitle:* ${activeSlide.subtitle || ""}\n\n${activeSlide.content}`;
    navigator.clipboard.writeText(text);
    setCopiedStatus("slide");
    setTimeout(() => {
      setCopiedStatus("idle");
    }, 2000);
  };

  const copyAllSlides = () => {
    const text = slides.map((slide, idx) => {
      return `### Slayd ${idx + 1}: ${slide.title}\n*Subtitle:* ${slide.subtitle || ""}\n*Layout:* ${slide.layout}\n*Accent:* ${slide.accentColor}\n\n${slide.content}\n\n---`;
    }).join("\n\n");
    navigator.clipboard.writeText(text);
    setCopiedStatus("all");
    setTimeout(() => {
      setCopiedStatus("idle");
    }, 2000);
  };

  const [downloadStatus, setDownloadStatus] = useState<"idle" | "loading" | "success">("idle");
  const [downloadProgress, setDownloadProgress] = useState(0);

  const handleDownloadTemplate = () => {
    if (!hasUnlocked) {
      onUpgradePrompt();
      return;
    }
    
    setDownloadStatus("loading");
    setDownloadProgress(0);
    
    const interval = setInterval(() => {
      setDownloadProgress((prev) => {
        if (prev >= 100) {
          clearInterval(interval);
          setDownloadStatus("success");
          
          try {
            const fileName = `${categoryConfig.id}_template_${slides.length}pg.txt`;
            const header = `=========================================\n${categoryConfig.uzLabel.toUpperCase()} PRESENTATION TEMPLATE\n=========================================\n`;
            const footer = `\n=========================================\nGenerated via SlideBuilder - Uzbek, Russian & English\n`;
            const content = slides.map((slide, idx) => {
              return `SLIDE ${idx + 1} [Layout: ${slide.layout.toUpperCase()} / Accent: ${slide.accentColor.toUpperCase()}]\n-----------------------------------------\nTITLE: ${slide.title}\nSUBTITLE: ${slide.subtitle || ""}\nCONTENT: ${slide.content}\n`;
            }).join("\n");
            
            const element = document.createElement("a");
            const file = new Blob([header + content + footer], { type: "text/plain;charset=utf-8" });
            element.href = URL.createObjectURL(file);
            element.download = fileName;
            document.body.appendChild(element);
            element.click();
            document.body.removeChild(element);
          } catch (e) {
            console.error("Download failed", e);
          }

          setTimeout(() => {
            setDownloadStatus("idle");
            setDownloadProgress(0);
          }, 3000);
          return 100;
        }
        return prev + 20;
      });
    }, 150);
  };

  const handlePageCountChange = (count: number) => {
    setSelectedPageCount(count);
    setSlides(generateCustomSlidesForCategory(lang, category, count));
    setActiveSlideIndex(0);
  };

  // Keyboard controls for full screen presentation
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (!isPresenting) return;
      if (e.key === "ArrowRight" || e.key === " ") {
        setActiveSlideIndex((prev) => (prev === slides.length - 1 ? 0 : prev + 1));
      } else if (e.key === "ArrowLeft") {
        setActiveSlideIndex((prev) => (prev === 0 ? slides.length - 1 : prev - 1));
      } else if (e.key === "Escape") {
        setIsPresenting(false);
      }
    };
    window.addEventListener("keydown", handleKeyDown);
    return () => window.removeEventListener("keydown", handleKeyDown);
  }, [isPresenting, slides.length]);

  // Color mapper helper for styles
  const getAccentBgClass = (color: string) => {
    switch (color) {
      case "violet": return "from-violet-950/60 to-purple-950/30 border-violet-800/60 text-violet-200";
      case "indigo": return "from-indigo-950/60 to-purple-950/30 border-indigo-800/60 text-indigo-200";
      case "rose": return "from-rose-950/60 to-purple-950/30 border-rose-800/60 text-rose-200";
      case "emerald": return "from-emerald-950/60 to-zinc-900/30 border-emerald-800/60 text-emerald-200";
      case "sky": return "from-sky-950/60 to-zinc-950/30 border-sky-800/60 text-sky-200";
      case "amber": return "from-amber-950/60 to-zinc-950/30 border-amber-800/60 text-amber-200";
      case "cyan": return "from-cyan-950/60 to-zinc-950/30 border-cyan-800/60 text-cyan-200";
      default: return "from-zinc-900 via-zinc-950 to-zinc-900 border-zinc-800 text-zinc-100";
    }
  };

  const getGlowShadow = (color: string) => {
    switch (color) {
      case "violet": return "shadow-[0_0_40px_rgba(139,92,246,0.15)]";
      case "indigo": return "shadow-[0_0_40px_rgba(99,102,241,0.15)]";
      case "rose": return "shadow-[0_0_40px_rgba(244,63,94,0.15)]";
      case "emerald": return "shadow-[0_0_40px_rgba(16,185,129,0.15)]";
      case "sky": return "shadow-[0_0_40px_rgba(56,189,248,0.15)]";
      case "amber": return "shadow-[0_0_40px_rgba(245,158,11,0.15)]";
      case "cyan": return "shadow-[0_0_40px_rgba(6,182,212,0.15)]";
      default: return "";
    }
  };

  return (
    <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-10">

      {/* Guest Login Prerequisite Shield */}
      {!user ? (
        <div 
          className="mb-12 p-8 rounded-3xl border border-teal-500/30 flex flex-col md:flex-row items-center justify-between gap-6 shadow-2xl relative overflow-hidden"
          style={{
            background: "linear-gradient(135deg, #071215, #03080b, #0c0e12)"
          }}
        >
          {/* Neon radial glow behind */}
          <div className="absolute -top-20 -left-20 h-40 w-40 rounded-full bg-teal-500/10 blur-3xl pointer-events-none" />
          
          <div className="flex items-center space-x-4 text-left relative z-10">
            <div className="p-3.5 rounded-2xl bg-zinc-950 text-teal-400 border border-teal-550/20 shadow-[0_0_20px_rgba(20,184,166,0.25)] flex items-center justify-center shrink-0">
              <Lock className="h-6 w-6 animate-pulse" />
            </div>
            <div>
              <h4 className="text-base font-black text-white flex items-center gap-2 tracking-wide uppercase font-sans">
                {t.guestWarning}
                <span className="py-0.5 px-2 text-[9px] bg-red-950/80 border border-red-500/30 text-red-400 font-mono rounded-full font-black uppercase">GUEST PROTECTION</span>
              </h4>
              <p className="text-xs text-slate-400 leading-relaxed max-w-2xl mt-1">
                {t.guestDescription}
              </p>
            </div>
          </div>
          
          <button
            onClick={onOpenLogin}
            className="w-full md:w-auto px-6 py-3 bg-gradient-to-r from-teal-500 to-indigo-650 hover:from-teal-400 hover:to-indigo-500 text-white text-xs font-black uppercase tracking-wider rounded-xl shadow-lg hover:scale-[1.02] active:scale-95 transition-all cursor-pointer flex items-center justify-center space-x-2 shrink-0"
          >
            <Sparkles className="h-4 w-4 text-yellow-350 animate-bounce" />
            <span>{t.loginBtnLabel}</span>
          </button>
        </div>
      ) : !hasUnlocked ? (
        /* Logged in, but template hasn't been paid/unlocked yet */
        <div 
          className="mb-12 p-6 rounded-3xl border border-amber-500/30 flex flex-col md:flex-row items-center justify-between gap-6 shadow-xl relative overflow-hidden"
          style={{
            background: "linear-gradient(135deg, #181105, #090602, #0d0d12)"
          }}
        >
          {/* Neon radial amber glow behind */}
          <div className="absolute -top-20 -right-20 h-40 w-40 rounded-full bg-amber-500/10 blur-3xl pointer-events-none" />

          <div className="flex items-center space-x-4 text-left relative z-10">
            <div className="p-3.5 rounded-2xl bg-zinc-950 text-amber-400 border border-amber-500/20 shadow-[0_0_15px_rgba(245,158,11,0.2)] flex items-center justify-center shrink-0 animate-bounce">
              <Crown className="h-6 w-6" />
            </div>
            <div>
              <h4 className="text-sm font-black text-white flex items-center gap-2 uppercase tracking-wider font-mono">
                {categoryConfig.uzLabel} - {t.oneTimeUnlock}
                <span className="py-0.5 px-2 text-[9px] bg-amber-955/80 border border-amber-500/30 text-amber-400 font-black rounded-full uppercase">LOCKED</span>
              </h4>
              <p className="text-xs text-slate-400 leading-relaxed max-w-2xl mt-1">
                {t.unlockDesc}
              </p>
            </div>
          </div>
          
          <button
            onClick={onUpgradePrompt}
            className="w-full md:w-auto px-6 py-3 bg-gradient-to-r from-amber-500 via-orange-500 to-rose-600 hover:from-amber-400 hover:to-rose-500 text-white text-xs font-black uppercase tracking-wider rounded-xl shadow-lg hover:scale-[1.02] active:scale-95 transition-all cursor-pointer flex items-center justify-center space-x-2 shrink-0"
          >
            <Sparkles className="h-4.5 w-4.5 text-yellow-300 animate-pulse" />
            <span>{t.unlockActionBtn}</span>
          </button>
        </div>
      ) : (
        /* Fully paid & unlocked template */
        <div 
          className="mb-12 p-6 rounded-3xl border border-teal-500/30 flex flex-col md:flex-row items-center justify-between gap-6 shadow-xl relative overflow-hidden"
          style={{
            background: "linear-gradient(135deg, #021a12, #000b06, #090e0c)"
          }}
        >
          <div className="flex items-center space-x-4 text-left relative z-10">
            <div className="p-3.5 rounded-2xl bg-zinc-950 text-teal-400 border border-teal-500/20 shadow-[0_0_15px_rgba(20,184,166,0.3)] flex items-center justify-center shrink-0">
              <Check className="h-6 w-6" />
            </div>
            <div>
              <h4 className="text-sm font-black text-white flex items-center gap-2 uppercase tracking-wider font-mono">
                {categoryConfig.uzLabel} - {t.purchasedCongrats}
                <span className="py-0.5 px-2 text-[9px] bg-teal-950/80 border border-teal-500/30 text-teal-400 font-black rounded-full uppercase">UNLOCKED</span>
              </h4>
              <p className="text-xs text-slate-400 leading-relaxed max-w-2xl mt-1">
                {t.purchasedDesc}
              </p>
            </div>
          </div>

          <div className="text-[10px] font-black text-teal-400 bg-teal-955/60 py-2 px-4 rounded-xl border border-teal-500/30 tracking-widest uppercase">
            👑 {t.logoTitle} MATCH
          </div>
        </div>
      )}

      {/* Editor top quick-status bar */}
      <div className="mb-8 flex flex-wrap items-center justify-between gap-4 border-b border-zinc-900 pb-5">
        <div className="text-left">
          <span className="text-[10px] font-mono tracking-widest text-teal-400 block uppercase font-bold">
            Miraculous Slides &bull; {categoryConfig.label} 
          </span>
          <h2 className="text-xl sm:text-2xl font-extrabold text-white uppercase">
            {t.previewMode}
          </h2>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          {/* Only let them copy/download slides if they unlocked first */}
          <button
            onClick={hasUnlocked ? copyActiveSlide : onUpgradePrompt}
            className={`flex items-center space-x-1.5 px-3.5 py-2.5 bg-zinc-900 hover:bg-zinc-800 border border-zinc-800 hover:border-zinc-700 rounded-xl text-xs font-bold transition-all cursor-pointer ${
              !hasUnlocked ? "opacity-40" : ""
            }`}
            id="copy-active-slide-btn"
          >
            {copiedStatus === "slide" ? (
              <>
                <Check className="h-3.5 w-3.5 text-teal-400" />
                <span className="text-teal-400">{t.copiedSuccess}</span>
              </>
            ) : (
              <>
                <Copy className="h-3.5 w-3.5 text-teal-400" />
                <span>{t.copySlide}</span>
              </>
            )}
          </button>

          <button
            onClick={hasUnlocked ? copyAllSlides : onUpgradePrompt}
            className={`flex items-center space-x-1.5 px-3.5 py-2.5 bg-zinc-900 hover:bg-zinc-800 border border-zinc-800 hover:border-teal-800/40 rounded-xl text-xs font-bold transition-all cursor-pointer ${
              !hasUnlocked ? "opacity-40" : ""
            }`}
            id="copy-all-slides-btn"
          >
            {copiedStatus === "all" ? (
              <>
                <Check className="h-3.5 w-3.5 text-teal-400" />
                <span className="text-teal-400 font-bold">{t.copiedAllSuccess}</span>
              </>
            ) : (
              <>
                <Copy className="h-3.5 w-3.5 text-sky-400 animate-pulse" />
                <span>{t.copyAll}</span>
              </>
            )}
          </button>

          {/* Download Template button */}
          <button
            onClick={handleDownloadTemplate}
            className={`flex items-center space-x-1.5 px-3.5 py-2.5 bg-zinc-900 hover:bg-zinc-800 border border-zinc-800 hover:border-amber-550/40 rounded-xl text-xs font-bold transition-all cursor-pointer relative overflow-hidden ${
              !hasUnlocked ? "opacity-40" : ""
            }`}
            id="download-template-btn"
          >
            {downloadStatus === "loading" ? (
              <>
                <span className="absolute bottom-0 left-0 h-[3px] bg-amber-500 transition-all duration-150" style={{ width: `${downloadProgress}%` }} />
                <div className="h-3.5 w-3.5 rounded-full border border-zinc-700 border-t-amber-500 animate-spin mr-1" />
                <span className="text-amber-400 font-mono">
                  {lang === "uz" ? `Yuklanmoqda... ${downloadProgress}%` : lang === "ru" ? `Загрузка... ${downloadProgress}%` : `Downloading... ${downloadProgress}%`}
                </span>
              </>
            ) : downloadStatus === "success" ? (
              <>
                <CheckCircle className="h-3.5 w-3.5 text-emerald-400 animate-bounce" />
                <span className="text-emerald-400 font-bold">
                  {lang === "uz" ? "Yuklandi! (.txt)" : lang === "ru" ? "Скачано! (.txt)" : "Downloaded! (.txt)"}
                </span>
              </>
            ) : (
              <>
                <Download className="h-3.5 w-3.5 text-amber-500 animate-pulse" />
                <span>
                  {lang === "uz" ? "Shablonni Yuklash" : lang === "ru" ? "Скачать шаблон" : "Download Template"}
                </span>
                {!hasUnlocked && <Lock className="h-3 w-3 text-zinc-500" />}
              </>
            )}
          </button>

          {/* Present (F5) button always clickable so they can see the gorgeous animations! */}
          <button
            onClick={() => setIsPresenting(true)}
            className="flex items-center space-x-2 px-5 py-2.5 bg-gradient-to-r from-teal-500 to-indigo-650 rounded-xl text-xs font-bold text-white shadow-lg lg:scale-100 cursor-pointer"
            id="start-presentation-btn"
          >
            <Play className="h-4 w-4 fill-current text-white animate-pulse" />
            <span>{t.presentationMode}</span>
          </button>
        </div>
      </div>

      {/* Primary Workspace Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
        
        {/* Left Side: Sidebar navigation list (Col index) */}
        <div className="lg:col-span-3 space-y-4">
                  <div className="bg-[#121214] rounded-2xl p-4 border border-zinc-800">
            <div className="flex items-center justify-between mb-4 border-b border-zinc-900/60 pb-2">
              <span className="text-xs font-bold text-zinc-300 font-mono">
                {t.slidesCount.toUpperCase()} ({slides.length})
              </span>
              <button
                onClick={hasUnlocked ? addSlide : onUpgradePrompt}
                className="p-1 px-2.5 bg-indigo-950/40 hover:bg-indigo-900/40 text-indigo-350 hover:text-white border border-indigo-800/40 rounded-lg text-[10px] font-bold tracking-wider transition-all flex items-center space-x-1 cursor-pointer"
                id="add-blank-slide-btn"
              >
                <Plus className="h-3 w-3" />
                <span>{t.addSlide}</span>
              </button>
            </div>

            {/* Vertically clickable slide indices */}
            <div className="space-y-2 max-h-[300px] overflow-y-auto pr-1">
              {slides.map((slide, idx) => {
                const isActive = idx === activeSlideIndex;
                return (
                  <div
                    key={slide.id}
                    onClick={() => setActiveSlideIndex(idx)}
                    className={`group relative flex items-center justify-between p-3 rounded-xl border cursor-pointer transition-all ${
                      isActive
                        ? "border-teal-500 bg-teal-950/20 text-white shadow-[0_0_15px_rgba(20,184,166,0.1)]"
                        : "border-zinc-850 bg-zinc-950 hover:bg-[#0d1618] text-slate-400 hover:text-zinc-200"
                    }`}
                    id="sidebar-slide-tile"
                  >
                    <div className="flex items-center space-x-2 overflow-hidden mr-2 font-mono">
                      <span className="text-[10px] text-teal-400 font-mono font-black tracking-tight">
                        0{idx + 1}
                      </span>
                      <span className="text-xs font-semibold truncate text-left font-sans">
                        {slide.title || "Untitled Slide"}
                      </span>
                    </div>

                    <button
                      type="button"
                      onClick={(e) => {
                        e.stopPropagation();
                        if (hasUnlocked) {
                          removeSlide(idx);
                        } else {
                          onUpgradePrompt();
                        }
                      }}
                      className="opacity-0 group-hover:opacity-100 p-1 hover:text-rose-455 text-slate-600 transition-all rounded cursor-pointer"
                    >
                      <Trash2 className="h-3.5 w-3.5" />
                    </button>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Slayd Sahifalari Sonini Tanlash (Page Count Selector) */}
          <div className="bg-[#121214] rounded-2xl p-4 border border-zinc-800 space-y-4">
            <div className="flex items-center space-x-1.5 border-b border-zinc-900/60 pb-2">
              <Layers className="h-4.5 w-4.5 text-teal-400 animate-pulse" />
              <span className="text-xs font-extrabold text-zinc-300 font-mono tracking-widest uppercase">
                {lang === "uz" ? "BETLAR SONI" : lang === "ru" ? "КОЛИЧЕСТВО СТРАНИЦ" : "PAGE COUNT"}
              </span>
            </div>

            <div className="space-y-3">
              <p className="text-[10.5px] text-slate-400 leading-relaxed">
                {lang === "uz" 
                  ? "Slaydlar to'plami g'oyasi uchun sahifalar sonini belgilang. Slaydlar soni tanlangan miqdorga moslab tayyorlanadi." 
                  : lang === "ru" 
                  ? "Задайте количество слайдов для вашего комплекта. Страницы будут перегенерированы." 
                  : "Set the number of slides for your deck. The slides will be instantly regenerated into that size."}
              </p>

              <div className="grid grid-cols-5 gap-1.5 pt-1">
                {[5, 10, 15, 20, 25].map((count) => {
                  const isSelected = slides.length === count;
                  return (
                    <button
                      key={count}
                      type="button"
                      onClick={() => handlePageCountChange(count)}
                      className={`py-2 text-xs font-bold font-mono rounded-xl border transition-all cursor-pointer text-center relative overflow-hidden ${
                        isSelected
                          ? "bg-teal-950/40 text-teal-300 border-teal-500 shadow-[0_0_12px_rgba(20,184,166,0.2)]"
                          : "bg-zinc-900 border-zinc-800 text-zinc-400 hover:text-zinc-200 hover:border-zinc-700"
                      }`}
                    >
                      <span className="block font-black text-xs">{count}</span>
                      <span className="block text-[8px] opacity-70 tracking-tight font-sans">
                        {lang === "uz" ? "bet" : lang === "ru" ? "стр" : "pg"}
                      </span>
                    </button>
                  );
                })}
              </div>

              <div className="text-[9.5px] text-zinc-500 font-mono flex items-center gap-1.5 bg-black/30 p-2 rounded-lg border border-zinc-900 leading-normal">
                <span className="h-1.5 w-1.5 rounded-full bg-teal-400 animate-pulse" />
                <span>
                  {lang === "uz" 
                    ? `Siz tanladingiz: ${slides.length} betli tayyor darslik andozasi.` 
                    : lang === "ru" 
                    ? `Вы выбрали: ${slides.length}-страничный шаблон.` 
                    : `Selected theme: ${slides.length}-page template.`}
                </span>
              </div>
            </div>
          </div>

        </div>

        {/* Center/Right Side: Live Slide Frame View & Active Form Editors */}
        <div className="lg:col-span-9 space-y-6">
          
          {/* Active Live Slide Card (Highly Polished Presentation Sheet) */}
          <div className="bg-zinc-950 rounded-3xl p-1 border border-zinc-90 w-full relative group">
            
            <div className="absolute top-4 right-4 z-10 flex items-center space-x-1 px-3 py-1 bg-black/60 backdrop-blur-md rounded-full border border-zinc-800 text-[9px] font-mono text-zinc-400 uppercase tracking-widest">
              <span>Slayd Rejimi: {activeSlide?.layout || "Oddiy"}</span>
            </div>

            {/* Glowing active preview slide sheet container */}
            <div 
              className={`w-full min-h-[320px] md:min-h-[360px] rounded-3xl p-8 flex flex-col justify-between relative overflow-hidden transition-all duration-500 border bg-gradient-to-br ${
                activeSlide ? getAccentBgClass(activeSlide.accentColor || "violet") : ""
              } ${activeSlide ? getGlowShadow(activeSlide.accentColor || "violet") : ""}`}
              id="slide-preview-card"
            >
              
              {/* Refractive gradient light beam */}
              <div className="absolute inset-0 bg-white/[0.02] pointer-events-none" />

              {/* Layout Render variations */}
              {activeSlide && (
                <AnimatePresence mode="wait">
                  <motion.div
                    key={activeSlide.id + activeSlide.layout}
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: -10 }}
                    className="grow flex flex-col justify-between"
                  >
                    
                    {/* Upper decorative layout indicators */}
                    <div className="flex items-center justify-between border-b border-white/5 pb-4 mb-4">
                      <div>
                        {activeSlide.subtitle && (
                          <span className="text-[10px] font-mono font-bold uppercase tracking-wider block opacity-70">
                            {activeSlide.subtitle}
                          </span>
                        )}
                      </div>
                      <span className="text-xs font-mono font-bold opacity-60">
                        {String(activeSlideIndex + 1).padStart(2, "0")}
                      </span>
                    </div>

                    {/* Core Contents */}
                    <div className="grow flex flex-col justify-center">
                      {activeSlide.layout === "hero" ? (
                        <div className="text-center space-y-4 py-4">
                          <h3 className="text-3xl sm:text-5xl font-black text-white leading-tight tracking-tight capitalize select-all">
                            {activeSlide.title}
                          </h3>
                          <p className="text-sm sm:text-base opacity-80 max-w-2xl mx-auto leading-relaxed select-all">
                            {activeSlide.content}
                          </p>
                        </div>
                      ) : activeSlide.layout === "split" ? (
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 items-center py-4">
                          <div className="text-left space-y-2">
                            <h3 className="text-2xl sm:text-3.5xl font-extrabold text-white leading-tight tracking-tight capitalize">
                              {activeSlide.title}
                            </h3>
                            <div className="h-1 w-12 bg-white/40 rounded" />
                          </div>
                          <div className="text-left">
                            <p className="text-xs sm:text-sm leading-relaxed opacity-85 select-all">
                              {activeSlide.content}
                            </p>
                          </div>
                        </div>
                      ) : activeSlide.layout === "quote" ? (
                        <div className="text-center space-y-5 max-w-xl mx-auto py-6">
                          <span className="text-4xl text-white/50 block font-serif">“</span>
                          <p className="text-sm sm:text-lg italic font-medium leading-relaxed text-white select-all">
                            {activeSlide.content}
                          </p>
                          <span className="text-xs font-bold uppercase tracking-widest text-white/80 block mt-2">
                            — {activeSlide.title}
                          </span>
                        </div>
                      ) : activeSlide.layout === "grid" ? (
                        <div className="space-y-4 py-4 text-left">
                          <h3 className="text-2xl font-extrabold text-white leading-tight tracking-tight capitalize">
                            {activeSlide.title}
                          </h3>
                          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 pt-2">
                            <div className="p-4 rounded-2xl bg-black/30 border border-white/5">
                              <span className="text-[10px] font-bold opacity-60 block mb-1">QISM I: REJA</span>
                              <p className="text-xs opacity-80 leading-relaxed select-all">
                                {activeSlide.content.substring(0, activeSlide.content.length / 2)}
                              </p>
                            </div>
                            <div className="p-4 rounded-2xl bg-black/30 border border-white/5">
                              <span className="text-[10px] font-bold opacity-60 block mb-1">QISM II: MAQSAD</span>
                              <p className="text-xs opacity-80 leading-relaxed select-all">
                                {activeSlide.content.substring(activeSlide.content.length / 2)}
                              </p>
                            </div>
                          </div>
                        </div>
                      ) : (
                        // Standard Simple layout
                        <div className="text-left space-y-4 py-4">
                          <h3 className="text-2xl sm:text-3.5xl font-extrabold text-white leading-tight tracking-tight capitalize">
                            {activeSlide.title}
                          </h3>
                          <p className="text-xs sm:text-sm leading-relaxed opacity-85 max-w-2xl select-all">
                            {activeSlide.content}
                          </p>
                        </div>
                      )}
                    </div>

                    {/* Lower pagination row */}
                    <div className="border-t border-white/5 pt-4 mt-4 flex items-center justify-between text-[10px] font-mono opacity-80">
                      <span>Rukn: {categoryConfig.label}</span>
                      <span>MIRACULOUS PRE-ANIMATED ENGINE</span>
                    </div>

                  </motion.div>
                </AnimatePresence>
              )}

            </div>
          </div>

          {/* Active slide metadata controllers */}
          {activeSlide && (
            <div className="bg-zinc-950/70 rounded-3xl p-6 border border-zinc-90 w-full grid grid-cols-1 md:grid-cols-3 gap-6 items-start shadow-xl">
              
              {/* Text Fields Editor column */}
              <div className="md:col-span-2 space-y-4">
                <h4 className="text-xs font-bold text-zinc-400 font-mono tracking-wider uppercase flex items-center space-x-1">
                  <FileText className="h-3.5 w-3.5" />
                  <span>{lang === "uz" ? "Slayd Matnini Tahrirlash" : lang === "ru" ? "Редактировать текст слайда" : "Edit Slide Texts"}</span>
                </h4>

                <div className="space-y-3">
                  <div>
                    <label className="block text-[10px] font-semibold text-zinc-500 mb-1" htmlFor="slide-title">
                      {t.slideTitle}
                    </label>
                    <input
                      type="text"
                      id="slide-title"
                      className="w-full bg-zinc-900 border border-zinc-800 focus:border-teal-450 rounded-xl px-4 py-2 text-xs text-white focus:outline-none"
                      value={activeSlide.title}
                      onChange={(e) => updateActiveSlide({ title: e.target.value })}
                    />
                  </div>

                  <div>
                    <label className="block text-[10px] font-semibold text-zinc-500 mb-1" htmlFor="slide-subtitle">
                      {t.slideSubtitle}
                    </label>
                    <input
                      type="text"
                      id="slide-subtitle"
                      className="w-full bg-zinc-900 border border-zinc-800 focus:border-teal-450 rounded-xl px-4 py-2 text-xs text-white focus:outline-none"
                      value={activeSlide.subtitle || ""}
                      onChange={(e) => updateActiveSlide({ subtitle: e.target.value })}
                    />
                  </div>

                  <div>
                    <label className="block text-[10px] font-semibold text-zinc-500 mb-1" htmlFor="slide-content">
                      {t.slideContent}
                    </label>
                    <textarea
                      id="slide-content"
                      rows={4}
                      className="w-full bg-zinc-900 border border-zinc-800 focus:border-teal-450 rounded-xl px-4 py-2 text-xs text-white focus:outline-none leading-relaxed"
                      value={activeSlide.content}
                      onChange={(e) => updateActiveSlide({ content: e.target.value })}
                    />
                  </div>
                </div>
              </div>

              {/* Design properties column */}
              <div className="space-y-5">
                
                {/* Layout selectors */}
                <div className="space-y-2">
                  <h4 className="text-xs font-bold text-zinc-400 font-mono tracking-wider uppercase flex items-center space-x-1">
                    <Layout className="h-3.5 w-3.5" />
                    <span>{t.slideLayout}</span>
                  </h4>
                  <div className="grid grid-cols-2 gap-2">
                    {[
                      { id: "simple", label: lang === "uz" ? "Oddiy" : lang === "ru" ? "Простой" : "Simple" },
                      { id: "hero", label: "Hero" },
                      { id: "split", label: "Split" },
                      { id: "grid", label: "Bento" },
                      { id: "quote", label: lang === "uz" ? "Iqtibos" : lang === "ru" ? "Цитата" : "Quote" }
                    ].map((lay) => (
                      <button
                        key={lay.id}
                        onClick={() => updateActiveSlide({ layout: lay.id as any })}
                        className={`py-1.5 px-2 text-[10px] font-bold rounded-lg border transition-all cursor-pointer ${
                          activeSlide.layout === lay.id
                            ? "bg-teal-950/40 text-teal-300 border-teal-700"
                            : "bg-zinc-900 border-zinc-800 text-zinc-500 hover:text-zinc-350"
                        }`}
                        id={`layout-selector-${lay.id}`}
                      >
                        {lay.label}
                      </button>
                    ))}
                  </div>
                </div>

                {/* Accent color selectors */}
                <div className="space-y-2">
                  <h4 className="text-xs font-bold text-zinc-400 font-mono tracking-wider uppercase flex items-center space-x-1">
                    <Palette className="h-3.5 w-3.5" />
                    <span>{t.accentColors}</span>
                  </h4>
                  <div className="flex flex-wrap gap-2">
                    {[
                      { id: "violet", class: "bg-violet-600" },
                      { id: "indigo", class: "bg-indigo-600" },
                      { id: "emerald", class: "bg-emerald-600" },
                      { id: "rose", class: "bg-rose-600" },
                      { id: "sky", class: "bg-sky-400" },
                      { id: "amber", class: "bg-amber-600" },
                      { id: "cyan", class: "bg-cyan-400" }
                    ].map((col) => (
                      <button
                        key={col.id}
                        onClick={() => updateActiveSlide({ accentColor: col.id })}
                        className={`h-6 w-6 rounded-full transition-all border cursor-pointer ${
                          activeSlide.accentColor === col.id
                            ? "ring-2 ring-white scale-110 border-white/20"
                            : "opacity-70 hover:opacity-100 border-transparent shadow"
                        } ${col.class}`}
                        title={col.id}
                        id={`accent-selector-${col.id}`}
                      />
                    ))}
                  </div>
                </div>

              </div>

            </div>
          )}

        </div>

      </div>

      {/* Cinematic Full screen Presentation Theatre Mode Overlay */}
      <AnimatePresence>
        {isPresenting && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 bg-black flex flex-col justify-between p-6 sm:p-12 font-sans select-none"
            id="theatre-presenting-mode"
          >
            
            {/* Upper controls bar */}
            <div className="flex items-center justify-between text-zinc-500 border-b border-zinc-900/50 pb-4">
              <div className="flex items-center space-x-2">
                <Crown className="h-4.5 w-4.5 text-yellow-500" />
                <span className="text-xs font-mono font-bold uppercase tracking-widest text-zinc-400">
                  Miraculous Slides Presentation Engine
                </span>
              </div>
              
              <button
                onClick={() => setIsPresenting(false)}
                className="flex items-center space-x-1.5 p-2 px-4 rounded-full border border-zinc-800 bg-zinc-950 text-xs font-bold text-zinc-300 hover:text-white transition-all font-mono"
              >
                <span>Chiqish</span>
                <X className="h-4.5 w-4.5" />
              </button>
            </div>

            {/* Central presentation viewport */}
            <div className="grow flex items-center justify-center py-10 w-full max-w-6xl mx-auto">
              {activeSlide && (
                <div 
                  className={`w-full h-full max-h-[500px] rounded-3xl p-10 md:p-16 flex flex-col justify-between relative overflow-hidden text-left border bg-gradient-to-br ${
                    getAccentBgClass(activeSlide.accentColor || "violet")
                  } ${getGlowShadow(activeSlide.accentColor || "violet")}`}
                >
                  <div className="absolute inset-0 bg-white/[0.015] pointer-events-none" />

                  {/* Header metadata inside full screen */}
                  <div className="flex items-center justify-between border-b border-white/5 pb-5">
                    <div>
                      {activeSlide.subtitle && (
                        <span className="text-xs sm:text-sm font-mono font-bold tracking-widest uppercase block opacity-80">
                          {activeSlide.subtitle}
                        </span>
                      )}
                    </div>
                    <span className="text-sm font-mono font-bold opacity-70">
                      Slide {activeSlideIndex + 1} of {slides.length}
                    </span>
                  </div>

                  {/* Dynamic full screen body render */}
                  <div className="grow flex flex-col justify-center my-6">
                    {activeSlide.layout === "hero" ? (
                      <div className="text-center space-y-6">
                        <h2 className="text-4xl sm:text-6xl font-black text-white leading-tight capitalize">
                          {activeSlide.title}
                        </h2>
                        <p className="text-base sm:text-xl opacity-80 max-w-3xl mx-auto leading-relaxed">
                          {activeSlide.content}
                        </p>
                      </div>
                    ) : activeSlide.layout === "split" ? (
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-8 items-center">
                        <div className="space-y-4">
                          <h2 className="text-3xl sm:text-5xl font-black text-white leading-tight capitalize">
                            {activeSlide.title}
                          </h2>
                          <div className="h-1 w-16 bg-white/50 rounded-full" />
                        </div>
                        <div>
                          <p className="text-sm sm:text-base opacity-85 leading-relaxed">
                            {activeSlide.content}
                          </p>
                        </div>
                      </div>
                    ) : activeSlide.layout === "quote" ? (
                      <div className="text-center space-y-6 max-w-2xl mx-auto">
                        <span className="text-6xl text-white/30 font-serif block">“</span>
                        <p className="text-lg sm:text-2xl italic font-bold leading-relaxed text-white">
                          {activeSlide.content}
                        </p>
                        <span className="text-sm font-black uppercase tracking-widest text-white/80 block mt-4">
                          — {activeSlide.title}
                        </span>
                      </div>
                    ) : activeSlide.layout === "grid" ? (
                      <div className="space-y-6 text-left">
                        <h2 className="text-3xl font-black text-white leading-tight capitalize">
                          {activeSlide.title}
                        </h2>
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 pt-2">
                          <div className="p-6 rounded-3xl bg-black/40 border border-white/5">
                            <span className="text-[11px] font-bold opacity-60 block mb-2 uppercase tracking-widest">QISM I</span>
                            <p className="text-xs sm:text-sm opacity-80 leading-relaxed">
                              {activeSlide.content.substring(0, activeSlide.content.length / 2)}
                            </p>
                          </div>
                          <div className="p-6 rounded-3xl bg-black/40 border border-white/5">
                            <span className="text-[11px] font-bold opacity-60 block mb-2 uppercase tracking-widest">QISM II</span>
                            <p className="text-xs sm:text-sm opacity-80 leading-relaxed">
                              {activeSlide.content.substring(activeSlide.content.length / 2)}
                            </p>
                          </div>
                        </div>
                      </div>
                    ) : (
                      <div className="space-y-4">
                        <h2 className="text-3xl sm:text-5xl font-black text-white leading-tight capitalize">
                          {activeSlide.title}
                        </h2>
                        <p className="text-sm sm:text-base opacity-85 leading-relaxed max-w-3xl">
                          {activeSlide.content}
                        </p>
                      </div>
                    )}
                  </div>

                  {/* Footer branding inside full screen */}
                  <div className="flex items-center justify-between border-t border-white/5 pt-5 opacity-70 text-[10px] font-mono">
                    <span>Katigoriya: {categoryConfig.uzLabel}</span>
                    <span>Andozaviy darslik taqdimoti</span>
                  </div>

                </div>
              )}
            </div>

            {/* Bottom cinematic navigation bar inside full screen */}
            <div className="flex items-center justify-between text-zinc-500 border-t border-zinc-900/50 pt-4">
              <span className="text-xs font-mono hidden sm:inline">
                Slaydlarni almashtirish uchun Yo'nalish tugmalarini bosing (A/D yoki Chap/O'ng)
              </span>

              <div className="flex items-center space-x-3 mx-auto sm:mx-0">
                <button
                  onClick={() => setActiveSlideIndex((prev) => (prev === 0 ? slides.length - 1 : prev - 1))}
                  className="p-3 bg-zinc-950 border border-zinc-800 hover:border-purple-600 rounded-full hover:text-white transition-all focus:outline-none"
                >
                  <ChevronLeft className="h-5 w-5" />
                </button>
                <span className="text-xs font-mono font-bold text-zinc-400 px-2 select-all">
                  {activeSlideIndex + 1} / {slides.length}
                </span>
                <button
                  onClick={() => setActiveSlideIndex((prev) => (prev === slides.length - 1 ? 0 : prev + 1))}
                  className="p-3 bg-zinc-950 border border-zinc-800 hover:border-purple-600 rounded-full hover:text-white transition-all focus:outline-none"
                >
                  <ChevronRight className="h-5 w-5" />
                </button>
              </div>
            </div>

          </motion.div>
        )}
      </AnimatePresence>

    </div>
  );
}
