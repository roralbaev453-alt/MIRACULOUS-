import React from "react";
import { CATEGORIES_LIST } from "../data";
import { CategoryId } from "../types";
import { Language, TRANSLATIONS } from "../translations";
import { 
  Compass, 
  BookOpen, 
  DraftingCompass, 
  TrendingUp, 
  Activity, 
  Atom, 
  Award, 
  Trees, 
  Construction 
} from "lucide-react";

interface CategoryGridProps {
  onSelectCategory: (catId: CategoryId) => void;
  selectedCategory: CategoryId;
  lang: Language;
}

// Map strings to Lucide icon components directly
const IconMapper: Record<string, React.ComponentType<{ className?: string }>> = {
  Compass: Compass,
  BookOpen: BookOpen,
  DraftingCompass: DraftingCompass,
  TrendingUp: TrendingUp,
  Activity: Activity,
  Atom: Atom,
  Award: Award,
  Trees: Trees,
  Construction: Construction,
};

export default function CategoryGrid({ onSelectCategory, selectedCategory, lang }: CategoryGridProps) {
  const t = TRANSLATIONS[lang];

  return (
    <section className="relative py-20 px-4 bg-[#09090b] border-t border-zinc-900">
      
      {/* Visual Background Beam */}
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 h-[600px] w-[600px] rounded-full bg-teal-900/5 blur-[120px] pointer-events-none" />

      <div className="mx-auto max-w-7xl">
        
        {/* Glowing Head Name matching Bento Grid title designPrecisely */}
        <div className="text-center mb-16">
          <h2 className="text-3xl sm:text-4xl md:text-5xl font-extrabold tracking-tight text-white uppercase select-none">
            {t.categoriesHeader}
            <span className="block mt-1 bg-gradient-to-r from-teal-400 via-sky-400 to-indigo-500 bg-clip-text text-transparent">
              {t.categoriesSubtitle}
            </span>
          </h2>
          <div className="h-0.5 w-16 bg-teal-500 mx-auto mt-4 rounded-full" />
        </div>

        {/* Categories Grid - 3x3 layout matching Bento styling */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 sm:gap-8">
          {CATEGORIES_LIST.map((category) => {
            const IconComponent = IconMapper[category.iconName] || Compass;
            const isSelected = selectedCategory === category.id;

            // Translate category name dynamically
            let catName = category.uzLabel;
            if (lang === "ru") {
              catName = category.id === "sayohat" ? t.travel 
                      : category.id === "tarix" ? t.history
                      : category.id === "arxitektura" ? t.architecture
                      : category.id === "biznes" ? t.business
                      : category.id === "medicina" ? t.medicine
                      : category.id === "fanlar" ? t.sciences
                      : category.id === "sport" ? t.sport
                      : category.id === "tabiyat" ? t.nature
                      : t.construction;
            } else if (lang === "en") {
              catName = category.label;
            }

            return (
              <button
                key={category.id}
                onClick={() => onSelectCategory(category.id)}
                className={`group relative text-left overflow-hidden rounded-3xl p-8 border-2 transition-all duration-300 hover:-translate-y-1 focus:outline-none focus:ring-2 focus:ring-teal-500 block w-full ${
                  isSelected
                    ? "border-teal-500 bg-[#121214] shadow-[0_0_30px_rgba(20,184,166,0.3)]"
                    : "border-zinc-800 bg-[#121214] hover:bg-zinc-90 w-full hover:border-slate-700"
                }`}
                id={`category-tile-${category.id}`}
              >
                
                {/* Glowing neon background slice */}
                <div 
                  className="absolute -top-16 -right-16 h-36 w-36 rounded-full blur-2xl opacity-10 group-hover:opacity-30 transition-opacity"
                  style={{ backgroundColor: isSelected ? "#20b8a6" : category.glowColor }}
                />

                {/* Left boundary accent strip mimicking grid boundary style */}
                <div 
                  className={`absolute left-0 top-6 bottom-6 w-1 rounded-r-lg transition-transform ${
                    isSelected ? "scale-y-100" : "scale-y-50 group-hover:scale-y-100"
                  }`}
                  style={{
                    background: isSelected 
                      ? "linear-gradient(to bottom, #14b8a6, #6366f1)" 
                      : "linear-gradient(to bottom, #1e293b, #475569)"
                  }}
                />

                {/* Card Icon & Metadata Header */}
                <div className="flex items-center justify-between mb-6 pl-2">
                  <div 
                    className="p-3.5 rounded-2xl border transition-colors flex items-center justify-center shadow-lg"
                    style={{
                      backgroundColor: "rgba(10, 10, 15, 0.8)",
                      borderColor: isSelected ? "rgba(20, 184, 166, 0.6)" : "rgba(39, 39, 42, 0.4)",
                      boxShadow: isSelected ? `0 4px 20px rgba(20, 184, 166, 0.2)` : "none"
                    }}
                  >
                    <IconComponent 
                      className={`h-7 w-7 transition-all ${
                        isSelected 
                          ? "text-teal-400 scale-110 drop-shadow-[0_0_10px_rgba(20,184,166,0.5)]" 
                          : "text-slate-400 group-hover:text-teal-400 group-hover:scale-105"
                      }`} 
                    />
                  </div>
                  
                  <span className="text-[10px] text-zinc-500 font-mono font-black uppercase tracking-widest block">
                    {category.label}
                  </span>
                </div>

                {/* Interactive labels */}
                <div className="pl-2 space-y-2">
                  <h3 className="text-lg font-black text-white tracking-wide uppercase font-sans">
                    {catName}
                  </h3>
                  <p className="text-slate-400 text-xs line-clamp-2 leading-relaxed">
                    {lang === "uz" ? category.description 
                     : lang === "ru" ? `Превосходный готовый анимированный шаблон в категории ${catName}. Идеально для уроков и презентаций.`
                     : `Outstanding prepared animated presentation slides regarding ${catName}. Ready to use straight out of the box.`}
                  </p>
                </div>

                {/* Lower Action bar indicator */}
                <div className="mt-6 pt-4 border-t border-zinc-900/65 pl-2 flex items-center justify-between">
                  <span className="text-[10px] text-slate-500 uppercase tracking-widest font-mono">
                    {category.templates.length}+ {t.templatesCount}
                  </span>
                  <span className="text-[11px] font-bold text-teal-400 opacity-0 group-hover:opacity-100 transition-opacity flex items-center space-x-1">
                    <span>{t.openButton}</span>
                    <span>&rarr;</span>
                  </span>
                </div>

              </button>
            );
          })}
        </div>

      </div>
    </section>
  );
}
