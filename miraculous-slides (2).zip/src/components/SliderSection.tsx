import React, { useState, useEffect } from "react";
import { SLIDER_CARDS } from "../data";
import { Language, TRANSLATIONS } from "../translations";
import { ArrowLeft, ArrowRight, Eye, Layers } from "lucide-react";
import { motion, AnimatePresence } from "motion/react";

interface SliderSectionProps {
  onSelectCategory: (catId: string) => void;
  lang: Language;
}

export default function SliderSection({ onSelectCategory, lang }: SliderSectionProps) {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [isPaused, setIsPaused] = useState(false);
  const t = TRANSLATIONS[lang];

  useEffect(() => {
    if (isPaused) return;
    const timer = setInterval(() => {
      setCurrentIndex((prev) => (prev === SLIDER_CARDS.length - 1 ? 0 : prev + 1));
    }, 4000);
    return () => clearInterval(timer);
  }, [isPaused]);

  const prev = () => {
    setCurrentIndex((prev) => (prev === 0 ? SLIDER_CARDS.length - 1 : prev - 1));
  };

  const next = () => {
    setCurrentIndex((prev) => (prev === SLIDER_CARDS.length - 1 ? 0 : prev + 1));
  };

  // Convert hand categories to appropriate category IDs for quick loading
  const getCatIdFromIndex = (idx: string): string => {
    if (idx === "1") return "sayohat";
    if (idx === "2") return "tarix";
    if (idx === "3") return "arxitektura";
    if (idx === "4") return "biznes";
    return "sayohat"; // default or others fallback
  };

  const getTranslatedCard = (idx: string) => {
    if (lang === "ru") {
      if (idx === "1") return { title: "Путешествия", desc: "Мир новых горизонтов и незабываемых приключений" };
      if (idx === "2") return { title: "История", desc: "История великих цивилизаций и уроки прошлого" };
      if (idx === "3") return { title: "Архитектура", desc: "Шедевры зодчества, дизайн зданий и умные дома" };
      if (idx === "4") return { title: "Бизнес", desc: "Инвестиции, стартапы и финансовый успех коммерции" };
      return { title: "И Другие", desc: "Медицина, спорт, наука и чудеса первозданной природы" };
    } else if (lang === "en") {
      if (idx === "1") return { title: "Travel", desc: "The universe of new horizons and unforgettable journeys" };
      if (idx === "2") return { title: "History", desc: "History of ancient empires and lessons of humanity" };
      if (idx === "3") return { title: "Architecture", desc: "Stunning landmarks, parametric drafts, and Eco-Smart homes" };
      if (idx === "4") return { title: "Business", desc: "Investments, innovative startups, and financial milestones" };
      return { title: "Others", desc: "Medicine, active sports, nature wonders, and physics sciences" };
    }
    // Default Uzbek
    if (idx === "1") return { title: "Sayohat", desc: "Yangi ufqlar va unutilmas sarguzashtlar olami" };
    if (idx === "2") return { title: "Tarix", desc: "Sivilizatsiyalar silsilasi va o'tmish saboqlari" };
    if (idx === "3") return { title: "Arxitektura & Qurilish", desc: "Me'morchilik durdonalari va aqlli uylar" };
    if (idx === "4") return { title: "Biznes", desc: "Sarmoya, startaplar va moliyaviy muvaffaqiyat" };
    return { title: "Va boshqalar", desc: "Meditsina, sport, fan va tabiat mo'jizalari" };
  };

  const activeTransCard = getTranslatedCard(SLIDER_CARDS[currentIndex].index);

  return (
    <section className="relative py-20 bg-[#09090b] overflow-hidden border-t border-zinc-900">
      
      {/* Glow Backdrops */}
      <div className="absolute top-1/2 left-1/4 -translate-y-1/2 h-[450px] w-[450px] rounded-full bg-teal-900/10 blur-[120px] pointer-events-none" />
      <div className="absolute top-1/3 right-1/4 h-[350px] w-[350px] rounded-full bg-teal-800/5 blur-[100px] pointer-events-none" />

      {/* Cyber Grid Pattern Backdrop */}
      <div className="absolute inset-0 bg-[linear-gradient(to_right,#0d9488_1px,transparent_1px),linear-gradient(to_bottom,#0d9488_1px,transparent_1px)] bg-[size:4rem_4rem] [mask-image:radial-gradient(ellipse_60%_50%_at_50%_50%,#000_70%,transparent_100%)] opacity-5 pointer-events-none" />

      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 relative z-10">
        
        {/* Top bar pagination control matches Image 2  */}
        <div className="flex items-center justify-between border-b border-zinc-805 pb-6 mb-12">
          
          {/* Current Page index indicator matching 01/08 style */}
          <div className="flex items-center space-x-2 font-mono text-sm tracking-wider text-slate-400">
            <span className="text-teal-400 font-bold text-base">
              0{currentIndex + 1}
            </span>
            <span className="text-slate-700">/</span>
            <span className="text-slate-550">0{SLIDER_CARDS.length}</span>
          </div>

          {/* Symmetrical glowing navigation arrows */}
          <div className="flex items-center space-x-3">
            <button
              onClick={prev}
              className="p-2.5 rounded-full border border-zinc-850 bg-zinc-950 text-slate-400 hover:text-white hover:border-teal-500 transition-all hover:shadow-[0_0_15px_rgba(20,184,166,0.3)] cursor-pointer"
              id="slider-nav-prev"
            >
              <ArrowLeft className="h-4.5 w-4.5" />
            </button>
            <button
              onClick={next}
              className="p-2.5 rounded-full border border-zinc-850 bg-zinc-950 text-slate-400 hover:text-white hover:border-teal-500 transition-all hover:shadow-[0_0_15px_rgba(20,184,166,0.3)] cursor-pointer"
              id="slider-nav-next"
            >
              <ArrowRight className="h-4.5 w-4.5" />
            </button>
          </div>
        </div>

        {/* Dynamic Display Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
          
          {/* Left panel: Floating Hands/Art Illustration with CSS Glow Title */}
          <div className="lg:col-span-6 flex flex-col items-center lg:items-start text-center lg:text-left space-y-6">
            
            <div className="relative">
              {/* Neon glowing handwriting Title replica from Image 2 */}
              <h3 className="text-4xl sm:text-5xl font-serif text-teal-400 font-normal italic tracking-tight drop-shadow-[0_0_15px_rgba(20,184,166,0.5)] leading-none select-none">
                Miraculous
              </h3>
              <h4 className="text-4xl sm:text-6xl font-black text-white/90 uppercase tracking-widest pl-4 -mt-1 font-sans">
                SLIDES
              </h4>
            </div>

            <p className="max-w-md text-slate-400 text-xs sm:text-sm leading-relaxed">
              {lang === "uz" 
                ? "Andozalarni tahlil qilish uchun o'zingizga ma'qul bo'lgan kartani bosing. Sayohat, tarix, arxitektura va biznes andozalari siz uchun maxsus dizaynerlar va muhandislar tomonidan ishlab chiqilgan."
                : lang === "ru" 
                ? "Нажмите на карту, чтобы проанализировать готовые анимированные шаблоны. Шаблоны путешествий, истории, архитектуры созданы профессиональными дизайнерами специально для Вас."
                : "Click on any active card to inspect prepared pre-animated slides. Travel, history, architecture, and business template packages were coded meticulously by industry-class team."}
            </p>

            {/* Circular Orbit deck of cards */}
            <div 
              className="relative w-80 h-80 flex items-center justify-center scale-90 sm:scale-100 transition-transform"
              onMouseEnter={() => setIsPaused(true)}
              onMouseLeave={() => setIsPaused(false)}
            >
              {/* Radial beam in the absolute center */}
              <div className="absolute h-40 w-40 rounded-full bg-gradient-to-tr from-teal-500/10 to-teal-500/5 blur-3xl pointer-events-none animate-pulse" />
              
              {/* Star orbit path circle */}
              <div className="absolute w-56 h-56 border border-dashed border-teal-500/25 rounded-full animate-spin [animation-duration:32s]" />
              <div className="absolute w-[225px] h-[225px] border border-zinc-800/60 rounded-full pointer-events-none" />

              {/* Central glowing core widget */}
              <div className="absolute w-20 h-20 rounded-full bg-teal-950/20 border border-teal-500/35 flex flex-col items-center justify-center pointer-events-none z-0">
                <div className="w-14 h-14 rounded-full bg-zinc-950 border border-dashed border-teal-500/15 flex flex-col items-center justify-center">
                  <span className="text-[8px] font-mono text-teal-400/85 font-black uppercase tracking-widest leading-none">AUTO</span>
                  <span className="text-[9px] font-mono text-zinc-400 font-extrabold tracking-wider mt-0.5">{isPaused ? "HOLD" : "ROLL"}</span>
                </div>
              </div>

              <div className="relative w-full h-full flex items-center justify-center">
                {/* Visual Glass Deck cards distributed on a circular orbit */}
                {SLIDER_CARDS.map((card, idx) => {
                  const isActive = idx === currentIndex;
                  const trans = getTranslatedCard(card.index);

                  // 5 cards spaced by 72 degrees each. -90deg places current active card at the top center.
                  const angleDeg = (idx - currentIndex) * 72 - 90;
                  const angleRad = (angleDeg * Math.PI) / 180;
                  const radius = 100; // Orbit track radius
                  
                  const x = radius * Math.cos(angleRad);
                  const y = radius * Math.sin(angleRad);

                  return (
                    <button
                      key={card.index}
                      onClick={() => setCurrentIndex(idx)}
                      className={`absolute w-36 h-20 rounded-xl border transition-all duration-700 ease-out cursor-pointer flex flex-col justify-between p-3 select-none text-left ${
                        isActive 
                          ? "border-teal-500 text-white z-30 scale-110 bg-zinc-900 shadow-[0_0_25px_rgba(20,184,166,0.3)] font-sans"
                          : "border-zinc-850 text-slate-400 opacity-60 z-10 scale-[0.80] bg-[#121214]/90 hover:opacity-100 hover:border-teal-500/40"
                      }`}
                      style={{
                        transform: `translate(${x}px, ${y}px) rotate(${(idx - currentIndex) * 6}deg)`,
                        backdropFilter: "blur(8px)"
                      }}
                    >
                      <span className="text-[9px] font-mono font-bold tracking-wider text-teal-400 block leading-none">
                        CARD {card.num}
                      </span>
                      <span className="text-xs font-black line-clamp-1 text-zinc-100 mt-1 leading-tight">{trans.title}</span>
                      <span className="text-[9px] text-zinc-400 line-clamp-1 leading-normal">{trans.desc}</span>
                    </button>
                  );
                })}
              </div>
            </div>

          </div>

          {/* Right panel: Grand detailed preview of current active sliding card */}
          <div className="lg:col-span-6">
            <AnimatePresence mode="wait">
              <motion.div
                key={currentIndex}
                initial={{ opacity: 0, x: 50, scale: 0.95 }}
                animate={{ opacity: 1, x: 0, scale: 1 }}
                exit={{ opacity: 0, x: -50, scale: 0.95 }}
                transition={{ duration: 0.4 }}
                className="relative overflow-hidden rounded-3xl p-8 border border-zinc-800 bg-[#121214] shadow-2xl group"
              >
                {/* Glowing neon top-right edge */}
                <div className="absolute top-0 right-0 h-28 w-28 bg-gradient-to-br from-teal-500/10 to-transparent rounded-full blur-xl" />

                {/* Index circle */}
                <div className="flex items-center justify-between mb-8">
                  <div className="h-10 w-10 flex items-center justify-center rounded-xl bg-slate-900 border border-slate-800 text-teal-400 font-mono font-bold text-sm shadow-sm shadow-teal-950/20">
                    {SLIDER_CARDS[currentIndex].num}
                  </div>
                  <div className="flex items-center space-x-1 py-1 px-3.5 rounded-full bg-zinc-950 border border-zinc-850">
                    <Layers className="h-3 w-3 text-teal-400" />
                    <span className="text-[10px] font-mono text-zinc-450">Ready Template Deck</span>
                  </div>
                </div>

                {/* Floating graphic element representing the physical cards */}
                <div className="space-y-4 mb-8">
                  <h4 className="text-2xl sm:text-3xl font-extrabold text-white">
                    {activeTransCard.title}
                  </h4>
                  <p className="text-slate-400 text-sm leading-relaxed">
                    {activeTransCard.desc}
                  </p>
                </div>

                {/* Uzbek translation/description metrics */}
                <div className="pt-6 border-t border-zinc-800/60 flex justify-between items-center">
                  <span className="text-xs text-slate-500 font-mono uppercase">{lang === "uz" ? "Holat:" : lang === "ru" ? "Статус:" : "Status:"}</span>
                  <span className="text-xs font-semibold text-emerald-450 font-mono uppercase tracking-widest">{lang === "uz" ? "Tayyor andoza" : lang === "ru" ? "Анимированный шаблон" : "Animated deck active"}</span>
                </div>

                {/* Interactive Click triggers presentation loading immediately */}
                <div className="mt-8">
                  <button
                    onClick={() => {
                      const catId = getCatIdFromIndex(SLIDER_CARDS[currentIndex].index);
                      onSelectCategory(catId);
                    }}
                    className="w-full relative flex items-center justify-center space-x-2 py-3.5 bg-[#030708] hover:bg-teal-950/30 border border-zinc-800 hover:border-teal-550 rounded-xl text-xs font-black uppercase tracking-widest text-[#00f3ff] hover:text-white transition-all shadow-md group-hover:shadow-teal-500/10 cursor-pointer"
                    id={`view-templates-btn-${currentIndex}`}
                  >
                    <Eye className="h-4 w-4 text-teal-400" />
                    <span>{t.openButton} &amp; {lang === "uz" ? "TAHRIRLASH" : lang === "ru" ? "ИЗМЕНИТЬ" : "EDIT TEMPLATE"}</span>
                  </button>
                </div>

              </motion.div>
            </AnimatePresence>
          </div>

        </div>

      </div>
    </section>
  );
}
