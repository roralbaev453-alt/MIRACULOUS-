export interface Slide {
  id: string;
  title: string;
  subtitle?: string;
  content: string;
  image?: string;
  layout: 'simple' | 'split' | 'hero' | 'grid' | 'quote';
  accentColor?: string;
}

export interface Presentation {
  id: string;
  title: string;
  category: CategoryId;
  slides: Slide[];
  createdAt: string;
}

export type CategoryId =
  | 'sayohat'
  | 'tarix'
  | 'arxitektura'
  | 'biznes'
  | 'medicina'
  | 'fanlar'
  | 'sport'
  | 'tabiyat'
  | 'qurilish';

export interface Category {
  id: CategoryId;
  label: string;
  uzLabel: string;
  iconName: string;
  description: string;
  themeColor: string;
  glowColor: string;
  templates: Slide[];
}

export interface User {
  email: string;
  name: string;
  isPremium: boolean;
  tier: number;
}

export type PaymentMethod = 'click' | 'payme' | 'visa';

export interface PaymentReceipt {
  id: string;
  amount: string;
  method: PaymentMethod;
  date: string;
  status: 'completed' | 'pending';
  tierName: string;
}
