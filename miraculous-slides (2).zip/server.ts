import express from "express";
import path from "path";
import dotenv from "dotenv";
import { GoogleGenAI, Type } from "@google/genai";
import { createServer as createViteServer } from "vite";

dotenv.config();

const app = express();
app.use(express.json());

const PORT = 3000;

// Lazy initialization of Gemini client
let aiClient: GoogleGenAI | null = null;
function getGeminiClient(): GoogleGenAI | null {
  if (!aiClient) {
    const key = process.env.GEMINI_API_KEY;
    if (key && key !== "MY_GEMINI_API_KEY") {
      aiClient = new GoogleGenAI({
        apiKey: key,
        httpOptions: {
          headers: {
            "User-Agent": "aistudio-build",
          },
        },
      });
    }
  }
  return aiClient;
}

// Fallback high-quality templates if AI is not available
const FallbackTemplates: Record<string, Array<{title: string; subtitle?: string; content: string; layout: string; accentColor: string}>> = {
  sayohat: [
    { title: "Dunyo Bo'ylab Sayohat", subtitle: "Unutilmas lahzalar sari", content: "Sayohat - bu faqat yangi joylarni ko'rish emas, balki yangi madaniyatlar, insonlar va o'zlikni kashf etish san'atidir.", layout: "hero", accentColor: "violet" },
    { title: "Safari Sarguzashtlari", subtitle: "Afrika yovvoyi tabiati", content: "Keniya va Tanzaniyaning cheksiz savannalarida yovvoyi tabiat bilan yaqindan tanishing va haqiqiy erkinlikni his qiling.", layout: "split", accentColor: "emerald" },
    { title: "Tarixiy Shaharlar", subtitle: "Yevropa merosi", content: "Rim, Parij va Praga kabi qadimiy shaharlarning ko'chalarida tarix nafasini his eting va me'morchilik durdonalaridan zavqlaning.", layout: "grid", accentColor: "amber" },
    { title: "Sayohat Maslahatlari", subtitle: "Sayohatni qulay rejalashtirish", content: "Minimal yuk bilan sayohat qiling, mahalliy taomlarni tatib ko'ring, har doim madaniy qadriyatlarga hurmat bilan yondashing.", layout: "simple", accentColor: "rose" }
  ],
  tarix: [
    { title: "Qadimgi Misr Sirlari", subtitle: "Fir'avnlar va ehromlar davri", content: "Nil vodiysida paydo bo'lgan bu buyuk sivilizatsiya o'zining piramidalari, ierogliflari va tibbiyot sirlari bilan insoniyatni hanuz lol qoldiradi.", layout: "hero", accentColor: "amber" },
    { title: "Buyuk Ipak Yo'li", subtitle: "Sivilizatsiyalar chorrahasi", content: "Sharq va G'arbni bog'lagan qadimiy savdo yo'li nafaqat ipak va ziravorlar, balki madaniyat, ilm-fan tarqalishiga xizmat qilgan.", layout: "split", accentColor: "indigo" },
    { title: "Temuriylar Renessansi", subtitle: "Ilm-fan va san'at gullagan davr", content: "Amir Temur va uning vorislari davrida Samarqand va Buxoro dunyo ilm-fan, yulduzshunoslik va nafis me'morchilik markaziga aylandi.", layout: "grid", accentColor: "indigo" }
  ],
  arxitektura: [
    { title: "Zamonaviy Arxitektura Shavki", subtitle: "Shisha va metall uyg'unligi", content: "Zamonaviy arxitektura tabiat bilan bir butun bo'lishga intiladi. Minimalizm va funksionallik bugungi loyihalarning tamal toshidir.", layout: "hero", accentColor: "sky" },
    { title: "Gotika Durdonalari", subtitle: "Samoga cho'zilgan minoralar", content: "O'rta asrlar gotika arxitekturasi o'zining yorug'lik o'yinlari, baland gumbazlari va vitrajli oynalari bilan ilohiy kuchni aks ettiradi.", layout: "split", accentColor: "violet" }
  ],
  biznes: [
    { title: "Raqamli Transformatsiya", subtitle: "Kelajak biznesi shu yerda", content: "Zamonaviy biznesda texnologiyalarni integratsiya qilish va sun'iy intellektdan unumli foydalanish raqobatbardoshlikni taminlaydi.", layout: "hero", accentColor: "violet" },
    { title: "Startaplar uchun Strategiya", subtitle: "G'oyadan investitsiyagacha", content: "Muvaffaqiyatli startap asosi - bu aniq muammoni topish, MVP yaratish va mijozlar fitbekini tezda tahlil qilishdir.", layout: "split", accentColor: "emerald" },
    { title: "Finans tahlili va Audit", subtitle: "Moliyaviy barqarorlik sirlari", content: "Soliq tahlili, pullar oqimi (Cash Flow) monitoringi va risklarni boshqarish har qanday korxonaning poydevoridir.", layout: "grid", accentColor: "indigo" }
  ],
  medicina: [
    { title: "Zamonaviy Kardiologiya", subtitle: "Yurak salomatligini saqlash", content: "Yangi invaziv bo'lmagan usullar va doimiy monitoring yurak xastaliklarini 80% gacha erta bosqichda aniqlashga yordam beradi.", layout: "hero", accentColor: "rose" },
    { title: "Sog'lom turmush tarzi", subtitle: "Profilaktika - davolashdan afzal", content: "To'g'ri uyqu, balanslashgan ovqatlanish va kunlik jismoniy faollik immun tizimini doimiy mustahkam holda saqlaydi.", layout: "simple", accentColor: "emerald" }
  ],
  fanlar: [
    { title: "Kvant Fizikasi", subtitle: "Mikroolam kashfiyotlari", content: "Kvant superpozitsiyasi va chalkashlik hodisalari bizning klassik fizika qonunlarimiz chegarasidan chiqib, yangi superkompyuterlarni yaratish imkonini beradi.", layout: "hero", accentColor: "violet" },
    { title: "Genomika va DNK", subtitle: "Hayot kodi sirlari", content: "CRISPR texnologiyasi yordamida genlarni tahrirlash irsiy kasalliklarni batamom davolash va tibbiyotda inqilob qilish ostonasida turibdi.", layout: "split", accentColor: "teal" }
  ],
  sport: [
    { title: "Professional Sport va Matonat", subtitle: "Olimpiada cho'qqilari", content: "Sport nafaqat jismoniy kuch, balki temirdek intizom va ruhan yengilmaslikdir. Har bir muvaffaqiyat ortida yillar mehnati bor.", layout: "hero", accentColor: "amber" },
    { title: "Krossfit va Chidamlilik", subtitle: "Kuchlilik chegaralari", content: "Yuqori intensivlikda bajariladigan funksional mashqlar chidamlilikni, metabolizmni va mushaklar kuchini oshirishda eng samarali yo'ldir.", layout: "split", accentColor: "rose" }
  ],
  tabiyat: [
    { title: "Ekologik muvozanat", subtitle: "Biz yashayotgan sayyora", content: "O'rmonlarni saqlash va karbonat angidrid chiqindilarini kamaytirish global iqlim isishini to'xtatishdagi eng asosiy vazifamizdir.", layout: "hero", accentColor: "emerald" },
    { title: "Okean tubi mo'jizalari", subtitle: "Tilsimli suv osti olami", content: "Okeanning eng chuqur Mariana botig'idagi kashf etilmagan biologik turlar hayotning ekstremal sharoitlarda ham qanchalik yashovchanligini ko'rsatadi.", layout: "split", accentColor: "cyan" }
  ],
  qurilish: [
    { title: "Yashil va Aqlli Binolar", subtitle: "Ekologik qurilish", content: "Energiya samaradorligi yuqori, mustaqil quyosh panellari bilan jihozlangan va suvni qayta ishlaydigan aqlli binolar kelajak qurilishidir.", layout: "hero", accentColor: "teal" },
    { title: "Sanoat va Muhandislik", subtitle: "Mustahkam poydevor", content: "Seysmik barqaror beton texnologiyalari va metall konstruksiyalar har qanday murakkab sharoitda uzoq yillik xavfsizlikni taminlaydi.", layout: "split", accentColor: "indigo" }
  ]
};

// API Route to generate presentation slides in Uzbek
app.post("/api/generate-slides", async (req, res) => {
  const { prompt, category, slideCount = 4 } = req.body;

  if (!prompt || !category) {
    return res.status(400).json({ error: "Sarlavha/Mavzu va rukn kiritilishi shart." });
  }

  const ai = getGeminiClient();

  // If Gemini client is not initialized, use fallback data
  if (!ai) {
    console.log("Gemini API is not configured or offline. Generating templates using fallback catalog.");
    const baseSlides = FallbackTemplates[category] || FallbackTemplates.biznes;
    // Map with a touch of customizing from user prompt
    const customized = baseSlides.map((s, idx) => ({
      id: `fallback-${idx}`,
      title: idx === 0 ? `${prompt}` : s.title,
      subtitle: s.subtitle,
      content: s.content,
      layout: s.layout,
      accentColor: s.accentColor,
    }));
    return res.json({ slides: customized, source: "fallback_catalog" });
  }

  try {
    const promptInstructions = `
      Siz professional taqdimotlar va slaydlar tuzuvchi assistantsiz.
      Foydalanuvchi quyidagi mavzu bo'yicha sarmoyadorlar, o'quvchilar yoki mijozlar uchun ajoyib slaydlar to'plamini (taqdimot) tuzishni istaydi:
      Mavzu/Prompt: "${prompt}"
      Rukn: "${category}"
      
      Slaydlar to'liq O'zbek tilida, professional va jozibador tilda yozilishi shart.
      Jami ${slideCount} dona slayd qaytaring.
      Har bir slayd uchun quyidagi xususiyatlar bo'lishi shart:
      1. title: Slayd nomi, qisqa va qiziqarli.
      2. subtitle: Qo'shimcha sarlavha (ixtiyoriy).
      3. content: Slaydning asosiy mazmuni. Batafsilroq va lo'nda bayon qilinsin (2-3 ta gapli chiroyli matn).
      4. layout: 'simple', 'split', 'hero', 'grid', yoki 'quote' ko'rinishlaridan biri bo'lishi kerak.
      5. accentColor: 'violet', 'indigo', 'rose', 'emerald', 'sky', 'amber', yoki 'cyan' ranglaridan biri bo'lishi kerak.
    `;

    const response = await ai.models.generateContent({
      model: "gemini-3.5-flash",
      contents: promptInstructions,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            slides: {
              type: Type.ARRAY,
              items: {
                type: Type.OBJECT,
                properties: {
                  title: { type: Type.STRING },
                  subtitle: { type: Type.STRING },
                  content: { type: Type.STRING },
                  layout: { type: Type.STRING, description: "One of: simple, split, hero, grid, quote" },
                  accentColor: { type: Type.STRING, description: "One of: violet, indigo, rose, emerald, sky, amber, cyan" },
                },
                required: ["title", "content", "layout", "accentColor"],
              },
            },
          },
          required: ["slides"],
        },
      },
    });

    let jsonStr = response.text?.trim() || "{}";
    const data = JSON.parse(jsonStr);

    if (data.slides && Array.isArray(data.slides)) {
      const formattedSlides = data.slides.map((s: any, idx: number) => ({
        id: `ai-${Date.now()}-${idx}`,
        title: s.title,
        subtitle: s.subtitle,
        content: s.content,
        layout: s.layout || "simple",
        accentColor: s.accentColor || "violet"
      }));
      return res.json({ slides: formattedSlides, source: "gemini_generation" });
    } else {
      throw new Error("Invalid structure returned from AI");
    }

  } catch (error: any) {
    console.error("Gemini Generation failed:", error);
    // Fallback on error
    const baseSlides = FallbackTemplates[category] || FallbackTemplates.biznes;
    const customized = baseSlides.map((s, idx) => ({
      id: `error-fallback-${idx}`,
      title: idx === 0 ? `${prompt}` : s.title,
      subtitle: s.subtitle,
      content: s.content,
      layout: s.layout,
      accentColor: s.accentColor,
    }));
    return res.json({ slides: customized, source: "error_fallback_catalog", error: error.message });
  }
});

// Configure Vite integration
async function startServer() {
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Express node server is running on http://localhost:${PORT}`);
  });
}

startServer();
